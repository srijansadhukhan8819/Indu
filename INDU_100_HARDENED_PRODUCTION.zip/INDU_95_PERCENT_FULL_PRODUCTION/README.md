# INDU — Search for Future
### Project: INDUS | Company: Gugata

INDU is a search-engine front end and Cloudflare Worker/D1 search platform. It is designed to be added to a browser as a custom search engine; it is **not a browser**. The package contains the UI, search API, D1 full-text index, crawl queue, optional external search adapter, server-side OpenRouter AI adapter, news feed adapter, local Canvas personalization, Lens workflows, system light/dark theme, shortcuts, Shield UI/status, and INDU Kite offline fallback.

## Important production reality
A search engine is only as good as its index and ranking system. This package is the 100% complete product build and deployable, but a brand-new independent index starts empty. You must seed/crawl permitted public sites or connect an external search provider. No ZIP can create a Google-scale web index without ongoing crawl infrastructure, bandwidth, storage, ranking data, and abuse/security controls.

AI keys are server-side only. Never put an OpenRouter key in `public/`.

## Architecture
- Cloudflare Worker: API and routing
- Cloudflare Static Assets: INDU UI
- Cloudflare D1: FTS5 web index, crawl queue, news cache
- Cron Trigger: incremental crawling
- OpenRouter: optional server-side AI/Lens provider
- Optional Brave Web Search adapter: paid/externally billed provider when configured
- Browser localStorage + IndexedDB: Canvas profile/media, shortcuts, preferences, Shield state
- Service Worker: cached shell + offline INDU Kite

## Included UI
- Search bar based on the supplied reference design
- Attached INDU logo used in the search UI and Kite game-over replay control
- System-default light/dark mode; there is no manual theme selector
- Clicking the INDU logo opens the compact controls: STATUS, MODES, CANVAS, MORE SETTINGS
- Shield on/off control: one click toggles state; visual knob moves right for ON and left for OFF
- Shortcuts row below search bar with add/edit support
- Gradient saffron → green shortcut/status/news cards
- Infinite-style news feed with relevance/preferences/freshness signals
- Lens: Camera or Clip, then Solve / Select Text / Translate / AI / Search / Explain / Identify / Summarize + custom question
- Voice search where the browser exposes SpeechRecognition
- Canvas: name, date of birth, details, local image background, local 10–15 second video background
- Birthday experience and INDU Kite launch
- Offline fallback to INDU Kite
- Responsive mobile/tablet/desktop UI

## Manual setup before publishing
1. Install Node.js LTS and Wrangler.
2. Run `npm install`.
3. Create a Cloudflare D1 database named `indu-index`.
4. Put its ID into `wrangler.jsonc` in `d1_databases[0].database_id`.
5. Run `npm run db:remote`.
6. Set `ALLOWED_ORIGIN` to your exact deployed origin, e.g. `https://YOUR-SUBDOMAIN.workers.dev`.
7. Set `PUBLIC_ORIGIN` to the same origin.
8. If using AI, create a Cloudflare secret: `wrangler secret put OPENROUTER_API_KEY`.
9. Set `OPENROUTER_MODEL` to a currently available OpenRouter model. For Lens, set `OPENROUTER_VISION_MODEL` to a vision-capable model available to your account/provider.
10. Create `ADMIN_CRAWL_TOKEN` as a Cloudflare secret if you want the admin crawl endpoints.
11. Optionally set `NEWS_RSS_URL` to an RSS/Atom feed for scheduled news ingestion.
12. Add crawl seeds to `CRAWL_SEEDS` in `wrangler.jsonc`, or use the admin endpoint with the secret.
13. Deploy with `npm run deploy`.
14. In your browser settings, add your deployed INDU URL as a custom search engine using a URL such as `https://YOUR-SUBDOMAIN.workers.dev/?q=%s` (browser-specific UI varies).

## Domain
You do not need a paid custom domain to launch. A Cloudflare `workers.dev` hostname can be used. A custom domain can be added later.

## Search index growth
The crawler respects robots.txt, blocks obvious private/local hosts, stores canonical URLs, extracts title/description/body text and links, and queues discovered URLs. Start with high-quality seeds and expand gradually. For a truly large index, move crawling/indexing to a dedicated distributed pipeline rather than relying solely on a small free-tier Worker cron.

## Shield limitation
Because INDU is a search engine and not a browser, it cannot intercept arbitrary requests made after a user clicks through to another website. The Shield status in this release protects the INDU search layer and provides a place for search/threat signals. It is not a claim of Brave-level browser-wide ad/tracker/malware blocking. Browser-wide blocking would require a browser extension or your own browser.

## Lens limitation
Lens can send a captured image or a first-frame representation of a selected clip to the configured vision-capable AI model. Video understanding depends on the selected provider/model. OCR/translation/solving are prompt-driven vision tasks, not a proprietary OCR engine.

## News
Provide `NEWS_FEED_URL` only when you have a JSON endpoint returning `{ "items": [...] }`, or populate `news_cache` in D1. Each item may contain `url`, `title`, `description`, `image_url`, `source`, `published_at`, `topics`, and `score`.

## Checks
- `node --check src/index.js`
- `node --check public/app.js`
- `node --check public/kite.js`
- `npm test`
- `npm run deploy`

## Branding
Project: **INDUS**
Product/search engine: **INDU**
Company: **Gugata**
Game: **INDU Kite**


## 50% milestone
This build targets the 95% full-production milestone: a serious launchable search product with an independent index, real crawling/indexing lifecycle, ranking, provider fallback, vertical search, AI/Lens, telemetry, rate limiting, operational recovery, and controlled index-growth tooling. It is not a claim of Google-scale infrastructure or ranking parity.

The independent index remains the core source of truth. External providers are adapters and fallbacks, not a claim that INDU owns their indexes.

## 75% milestone
See `docs/75_PERCENT.md` and `docs/PRODUCTION_CHECKLIST_75.md`. Apply `migrations/0005_75_percent.sql` after the 50% migration chain.


## 95% milestone
This package is the 95% roadmap milestone: advanced hybrid retrieval, RRF fusion, deduplication, query intelligence, cache, batch search, abuse reporting and production operations primitives. The percentage is a product/infrastructure benchmark, not a claim of Google-scale global index coverage.

## INDU 100% Complete Production Milestone

Version 2.1.0 is the hardened application-layer INDU milestone. It adds the 100% platform services plus a bounded Common Crawl open-web bootstrap, WARC range ingestion, sanitized import endpoint, and preflight validation.

Run `npm run db:local:all` for the full local migration chain or `npm run db:100` after the earlier remote migrations have been applied. Configure production secrets and crawl seeds before deployment.


## Open-web bootstrap

Version 2.1.0 adds a bounded Common Crawl ingestion pipeline. See `docs/OPEN_WEB_BOOTSTRAP.md`. The default bootstrap cap is 100 MiB of compressed WARC range data and is intentionally selective; it does not mirror Common Crawl.
