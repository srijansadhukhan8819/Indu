# Security policy

INDU is a search engine, not a browser.

Do not expose API keys in frontend assets. Use Cloudflare Worker secrets.

Before public launch:
- set a strong ADMIN_CRAWL_TOKEN;
- rate-limit admin endpoints;
- restrict/monitor crawl volume;
- enforce robots.txt and publisher policies;
- add abuse controls for search/AI endpoints;
- configure CSP and other response security headers for your production domain;
- review third-party API terms;
- validate all user URLs and uploaded media;
- never execute crawled JavaScript;
- do not allow server-side requests to private/local network addresses.

The current crawler blocks common private/local host ranges, but production hardening should include a dedicated egress/SSRF strategy if crawler scope expands.
