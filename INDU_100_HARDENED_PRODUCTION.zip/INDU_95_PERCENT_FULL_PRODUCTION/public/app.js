(() => {
  "use strict";

  const $ = (s, r=document) => r.querySelector(s);
  const $$ = (s, r=document) => [...r.querySelectorAll(s)];
  const modal = $("#modal");
  const modalContent = $("#modalContent");
  const qInput = $("#q");
  const logoPanel = $("#logoPanel");
  const shieldToggle = $("#shieldToggle");
  const toastEl = $("#toast");
  const storage = window.localStorage;
  const DB = {
    shortcuts: "indu.shortcuts.v1",
    canvas: "indu.canvas.v1",
    shield: "indu.shield.v1",
    stats: "indu.stats.v1",
    mode: "indu.mode.v1",
    history: "indu.history.v1",
    newsPrefs: "indu.news.prefs.v1"
  };

  const CanvasDB = {
    open() {
      return new Promise((resolve,reject)=>{
        const r=indexedDB.open("indu-canvas-media-v1",1);
        r.onupgradeneeded=()=>r.result.createObjectStore("media");
        r.onsuccess=()=>resolve(r.result);
        r.onerror=()=>reject(r.error);
      });
    },
    async put(key, blob) {
      const db=await this.open();
      return new Promise((resolve,reject)=>{const tx=db.transaction("media","readwrite");tx.objectStore("media").put(blob,key);tx.oncomplete=()=>{db.close();resolve()};tx.onerror=()=>{db.close();reject(tx.error)};});
    },
    async get(key) {
      const db=await this.open();
      return new Promise((resolve,reject)=>{const tx=db.transaction("media","readonly");const r=tx.objectStore("media").get(key);r.onsuccess=()=>{db.close();resolve(r.result||null)};r.onerror=()=>{db.close();reject(r.error)};});
    },
    async clear() {
      const db=await this.open();
      return new Promise((resolve,reject)=>{const tx=db.transaction("media","readwrite");tx.objectStore("media").clear();tx.oncomplete=()=>{db.close();resolve()};tx.onerror=()=>{db.close();reject(tx.error)};});
    }
  };

  const defaults = [
    {name:"Google", url:"https://www.google.com/"},
    {name:"YouTube", url:"https://www.youtube.com/"},
    {name:"GitHub", url:"https://github.com/"},
    {name:"Wikipedia", url:"https://www.wikipedia.org/"}
  ];

  const safeJSON = (key, fallback) => {
    try { return JSON.parse(storage.getItem(key) || JSON.stringify(fallback)); } catch { return fallback; }
  };
  const save = (key, value) => { try { storage.setItem(key, JSON.stringify(value)); } catch {} };
  const escapeHTML = s => String(s ?? "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
  const toast = msg => { toastEl.textContent=msg; toastEl.classList.add("show"); clearTimeout(toast._t); toast._t=setTimeout(()=>toastEl.classList.remove("show"),2600); };

  // System theme only: no theme setting is exposed.
  const media = matchMedia("(prefers-color-scheme: dark)");
  const applyTheme = () => document.documentElement.dataset.theme = media.matches ? "dark" : "light";
  applyTheme(); media.addEventListener?.("change", applyTheme);

  let stats = safeJSON(DB.stats, {ads:0, trackers:0, threats:0});
  let shieldOn = storage.getItem(DB.shield) !== "off";
  shieldToggle.checked = shieldOn;

  function renderStats() {
    $("#adsCount").textContent = stats.ads.toLocaleString();
    $("#trackersCount").textContent = stats.trackers.toLocaleString();
    $("#threatsCount").textContent = stats.threats.toLocaleString();
    $("#statusLive").textContent = shieldOn ? "SHIELD ON" : "SHIELD OFF";
    $("#shieldQuick").classList.toggle("off", !shieldOn);
  }
  renderStats();

  function renderShortcuts() {
    const el=$("#shortcuts");
    const list=safeJSON(DB.shortcuts, defaults);
    el.innerHTML="";
    list.forEach((item,i)=>{
      const a=document.createElement("a");
      a.className="shortcut";
      a.href=item.url;
      a.target="_blank";
      a.rel="noopener noreferrer nofollow";
      a.title=item.url;
      a.innerHTML=`<span class="shortcut-icon">${escapeHTML((item.name||"?").slice(0,1).toUpperCase())}</span><span>${escapeHTML(item.name)}</span>`;
      a.addEventListener("contextmenu", e=>{e.preventDefault(); openShortcutEditor(i);});
      el.appendChild(a);
    });
  }
  renderShortcuts();

  function openModal(html) { modalContent.innerHTML=html; modal.hidden=false; document.body.classList.add("modal-open"); }
  function closeModal() { modal.hidden=true; modalContent.innerHTML=""; document.body.classList.remove("modal-open"); }
  modal.addEventListener("click", e=>{ if(e.target.matches("[data-close]")) closeModal(); });

  $("#induLogo").addEventListener("click", e=>{
    e.stopPropagation();
    logoPanel.hidden=!logoPanel.hidden;
  });
  document.addEventListener("click", e=>{
    if(!logoPanel.hidden && !logoPanel.contains(e.target) && !$("#induLogo").contains(e.target)) logoPanel.hidden=true;
  });

  $$("[data-panel]").forEach(btn=>btn.addEventListener("click",()=>{
    logoPanel.hidden=true;
    openPanel(btn.dataset.panel);
  }));

  function openPanel(type) {
    if(type==="status") return openStatus();
    if(type==="modes") return openModes();
    if(type==="canvas") return openCanvas();
    if(type==="settings") return openSettings();
  }

  function openStatus() {
    openModal(`
      <div class="modal-head"><h2>STATUS</h2><button class="close" data-close>×</button></div>
      <div class="status-large">
        <div><b>${stats.ads.toLocaleString()}</b><span>ADS BLOCKED ON INDU</span></div>
        <div><b>${stats.trackers.toLocaleString()}</b><span>TRACKERS BLOCKED ON INDU</span></div>
        <div><b>${stats.threats.toLocaleString()}</b><span>THREATS FILTERED</span></div>
      </div>
      <p class="muted">These counters represent events recorded by INDU's implemented search-level protection. INDU is a search engine and does not control arbitrary third-party webpages opened in your browser.</p>
    `);
  }

  function openModes() {
    const modes=["AUTO","RESEARCH","CODING","CYBER SECURITY","NEWS","IMAGES"];
    const active=storage.getItem(DB.mode)||"AUTO";
    openModal(`
      <div class="modal-head"><h2>MODES</h2><button class="close" data-close>×</button></div>
      <div class="mode-grid">${modes.map(m=>`<button class="mode-option ${m===active?"active":""}" data-mode="${escapeHTML(m)}">${escapeHTML(m)}</button>`).join("")}</div>
    `);
    $$(".mode-option",modalContent).forEach(b=>b.addEventListener("click",()=>{
      storage.setItem(DB.mode,b.dataset.mode);
      closeModal(); toast(`MODE: ${b.dataset.mode}`);
    }));
  }

  function openCanvas() {
    const c=safeJSON(DB.canvas,{name:"",dob:"",details:""});
    openModal(`
      <div class="modal-head"><h2>CANVAS</h2><button class="close" data-close>×</button></div>
      <form id="canvasForm" class="settings-form">
        <label>Name<input name="name" value="${escapeHTML(c.name)}" maxlength="80"></label>
        <label>Date of birth<input name="dob" type="date" value="${escapeHTML(c.dob)}"></label>
        <label>Other details<textarea name="details" maxlength="1000">${escapeHTML(c.details)}</textarea></label>
        <label>Background image<input name="background" type="file" accept="image/*"></label>
        <label>10–15 second background clip<input name="video" type="file" accept="video/*"></label>
        <div class="media-preview" id="canvasPreview"></div>
        <button class="primary" type="submit">SAVE CANVAS</button>
        <button class="secondary" type="button" id="clearCanvas">CLEAR LOCAL CANVAS</button>
      </form>
      <p class="muted">Canvas text settings use local browser storage. Images and video are stored as local device Blobs in IndexedDB; they are not uploaded by this v1 implementation.</p>
    `);
    $("#canvasForm").addEventListener("submit", saveCanvas);
    $("#clearCanvas").addEventListener("click",async()=>{try{storage.removeItem(DB.canvas);await CanvasDB.clear();await applyCanvas({});closeModal();toast("Canvas cleared");}catch{toast("Could not clear Canvas");}});
    loadCanvasPreview();
  }

  async function loadCanvasPreview(){
    const p=$("#canvasPreview"); if(!p) return;
    try{
      const image=await CanvasDB.get("background"), video=await CanvasDB.get("video");
      if(image) p.insertAdjacentHTML("beforeend",`<img src="${URL.createObjectURL(image)}" alt="Canvas background">`);
      if(video) p.insertAdjacentHTML("beforeend",`<video src="${URL.createObjectURL(video)}" muted loop autoplay playsinline></video>`);
    }catch{}
  }

  async function saveCanvas(e) {
    e.preventDefault();
    try {
      const f=e.target;
      const old=safeJSON(DB.canvas,{});
      const image=f.background.files[0], video=f.video.files[0];
      if(image){
        if(image.size>8_000_000) throw new Error("Image is too large for local Canvas.");
        await CanvasDB.put("background",image);
      }
      if(video){
        if(video.size>40_000_000) throw new Error("Video is too large for local Canvas. Keep the clip around 10–15 seconds and under 40 MB.");
        await CanvasDB.put("video",video);
      }
      const c={name:f.name.value.trim(),dob:f.dob.value,details:f.details.value.trim()};
      save(DB.canvas,c); await applyCanvas(c); closeModal(); toast("Canvas saved on this device");
    } catch(err) { toast(err.message || "Could not save Canvas"); }
  }

  async function applyCanvas(c) {
    const vb=$("#canvasVideoBg");
    document.body.style.backgroundImage="";
    try{
      const image=await CanvasDB.get("background"), video=await CanvasDB.get("video");
      if(image) {
        const old=document.body.dataset.canvasImageUrl;
        if(old) URL.revokeObjectURL(old);
        const u=URL.createObjectURL(image);
        document.body.dataset.canvasImageUrl=u;
        document.body.style.backgroundImage=`url("${u}")`;
      }
      if(vb){
        if(video){
          if(vb.dataset.objectUrl) URL.revokeObjectURL(vb.dataset.objectUrl);
          const u=URL.createObjectURL(video); vb.dataset.objectUrl=u; vb.src=u; vb.classList.add("active"); vb.play().catch(()=>{});
        } else {
          if(vb.dataset.objectUrl) URL.revokeObjectURL(vb.dataset.objectUrl);
          vb.pause(); vb.removeAttribute("src"); vb.load(); vb.classList.remove("active");
        }
      }
      document.body.classList.toggle("has-canvas", !!(image||video));
    }catch{
      document.body.classList.remove("has-canvas");
    }
  }
  applyCanvas(safeJSON(DB.canvas,{}));

  function openSettings() {
    openModal(`
      <div class="modal-head"><h2>MORE SETTINGS</h2><button class="close" data-close>×</button></div>
      <div class="settings-list">
        <button data-setting="privacy">PRIVACY</button>
        <button data-setting="search">SEARCH</button>
        <button data-setting="security">SECURITY</button>
        <button data-setting="ai">AI</button>
        <button data-setting="shortcuts">SHORTCUTS</button>
        <button data-setting="news">NEWS</button>
        <button data-setting="accessibility">ACCESSIBILITY</button>
      </div>
      <p class="muted">Light/Dark appearance follows the device/browser system setting automatically. There is no manual theme switch.</p>
    `);
    $$(".settings-list button",modalContent).forEach(b=>b.addEventListener("click",()=>openSettingDetail(b.dataset.setting)));
  }

  function openSettingDetail(type) {
    const titles={privacy:"PRIVACY",search:"SEARCH",security:"SECURITY",ai:"AI",shortcuts:"SHORTCUTS",news:"NEWS",accessibility:"ACCESSIBILITY"};
    const bodies={
      privacy:`<label><input type="checkbox" checked disabled> Minimize unnecessary INDU data retention</label><label><input type="checkbox" checked disabled> Canvas stays on this device</label><button class="danger" id="clearLocal">CLEAR LOCAL INDU DATA</button>`,
      search:`<label>Default mode<select id="defaultMode"><option>AUTO</option><option>RESEARCH</option><option>CODING</option><option>CYBER SECURITY</option><option>NEWS</option><option>IMAGES</option></select></label><label>Results per search<select id="resultsCount"><option>10</option><option selected>20</option><option>30</option></select></label>`,
      security:`<label><input id="secShield" type="checkbox" ${shieldOn?"checked":""}> Shield enabled</label><p class="muted">Search-level protection only. INDU cannot control arbitrary third-party pages in your browser.</p>`,
      ai:`<p>INDU AI is routed server-side. The OpenRouter credential is never stored in the browser.</p><label><input id="aiAnswers" type="checkbox" checked> Enable AI answers when requested</label>`,
      shortcuts:`<button class="primary" id="manageShortcuts">MANAGE SHORTCUTS</button><p class="muted">Long-press/right-click a shortcut to edit it.</p>`,
      news:`<label>Topics<input id="newsTopics" placeholder="technology, science, sports, India"></label><button class="primary" id="saveNewsPrefs">SAVE NEWS PREFERENCES</button><p class="muted">INDU uses these preferences as one ranking signal alongside relevance, freshness and importance.</p>`,
      accessibility:`<label><input id="reduceMotion" type="checkbox"> Reduce motion</label><label><input id="largeText" type="checkbox"> Larger text</label>`
    };
    openModal(`<div class="modal-head"><h2>${titles[type]}</h2><button class="close" data-close>×</button></div><div class="settings-form">${bodies[type]}</div>`);
    $("#clearLocal")?.addEventListener("click",()=>{for(const k of Object.values(DB)) storage.removeItem(k); location.reload();});
    $("#secShield")?.addEventListener("change",e=>setShield(e.target.checked));
    $("#manageShortcuts")?.addEventListener("click",()=>openShortcutEditor());
    if(type==="news"){
      const prefs=safeJSON("indu.news.prefs.v1",[]);
      const field=$("#newsTopics"); if(field) field.value=prefs.join(", ");
      $("#saveNewsPrefs")?.addEventListener("click",()=>{const vals=$("#newsTopics").value.split(",").map(x=>x.trim().toLowerCase()).filter(Boolean).slice(0,12);save("indu.news.prefs.v1",vals);closeModal();loadNews(true);toast("News preferences saved");});
    }
    $("#reduceMotion")?.addEventListener("change",e=>document.documentElement.classList.toggle("reduce-motion",e.target.checked));
    $("#largeText")?.addEventListener("change",e=>document.documentElement.classList.toggle("large-text",e.target.checked));
  }

  function openShortcutEditor(index=null) {
    const list=safeJSON(DB.shortcuts,defaults);
    const item=index===null?{name:"",url:""}:list[index];
    openModal(`
      <div class="modal-head"><h2>${index===null?"ADD SHORTCUT":"EDIT SHORTCUT"}</h2><button class="close" data-close>×</button></div>
      <form id="shortcutForm" class="settings-form">
        <label>Name<input name="name" required maxlength="40" value="${escapeHTML(item.name)}"></label>
        <label>Website URL<input name="url" required type="url" placeholder="https://example.com" value="${escapeHTML(item.url)}"></label>
        <button class="primary" type="submit">SAVE</button>
        ${index!==null?`<button class="danger" type="button" id="deleteShortcut">DELETE</button>`:""}
      </form>
    `);
    $("#shortcutForm").addEventListener("submit",e=>{
      e.preventDefault();
      let url=e.target.url.value.trim();
      try { const u=new URL(url); if(!["http:","https:"].includes(u.protocol)) throw new Error(); url=u.href; } catch { toast("Enter a valid HTTP/HTTPS URL"); return; }
      if(index===null) list.push({name:e.target.name.value.trim(),url}); else list[index]={name:e.target.name.value.trim(),url};
      save(DB.shortcuts,list); renderShortcuts(); closeModal(); toast("Shortcut saved");
    });
    $("#deleteShortcut")?.addEventListener("click",()=>{list.splice(index,1);save(DB.shortcuts,list);renderShortcuts();closeModal();toast("Shortcut deleted");});
  }
  $("#addShortcut").addEventListener("click",()=>openShortcutEditor());

  shieldToggle.addEventListener("change",e=>setShield(e.target.checked));
  $("#shieldQuick").addEventListener("click",()=>{setShield(!shieldOn); toast(shieldOn?"Shield ON":"Shield OFF");});
  function setShield(v) { shieldOn=!!v; shieldToggle.checked=shieldOn; storage.setItem(DB.shield,shieldOn?"on":"off"); renderStats(); }

  let newsOffset = 0;
  async function loadNews(reset=false){
    if(reset) newsOffset=0;
    const feed=$("#newsFeed"), sentinel=$("#newsSentinel"); if(!feed)return;
    if(reset) feed.innerHTML='<div class="news-loading">Loading relevant stories…</div>';
    try{const r=await fetch(`/api/news?offset=${newsOffset}&limit=12`);const d=await r.json();const prefs=safeJSON(DB.newsPrefs,[]).map(x=>x.toLowerCase());const items=(d.items||[]).slice().sort((a,b)=>{const pa=prefs.reduce((n,p)=>n+((a.title||'')+' '+(a.description||'')).toLowerCase().includes(p)?3:0,0),pb=prefs.reduce((n,p)=>n+((b.title||'')+' '+(b.description||'')).toLowerCase().includes(p)?3:0,0);return (pb+Number(b.score||0))-(pa+Number(a.score||0));});
      if(reset)feed.innerHTML='';
      if(!items.length && newsOffset===0){feed.innerHTML='<div class="news-loading">No news feed is configured yet.</div>';sentinel.textContent='';return;}
      feed.insertAdjacentHTML('beforeend',items.map(n=>`<article class="news-item"><a href="${escapeHTML(n.url||'#')}" target="_blank" rel="noopener noreferrer"><div class="news-source">${escapeHTML(n.source||'INDU')}</div><h3>${escapeHTML(n.title||'Untitled')}</h3><p>${escapeHTML(n.description||'')}</p></a></article>`).join(''));
      newsOffset+=items.length; sentinel.textContent=d.hasMore?'Loading more…':'END OF CURRENT FEED';
    }catch{if(newsOffset===0)feed.innerHTML='<div class="news-loading">News is temporarily unavailable.</div>';sentinel.textContent='';}
  }
  function setupBirthday(){const c=safeJSON(DB.canvas,{});const el=$("#canvasGreeting");if(!el)return;const name=(c.name||'').trim();if(!name){el.textContent='';return;}const today=new Date(), dob=c.dob?new Date(c.dob+'T00:00:00'):null;const birthday=dob&&dob.getMonth()===today.getMonth()&&dob.getDate()===today.getDate();el.textContent=birthday?`HAPPY BIRTHDAY, ${name.toUpperCase()} ✦`:`${name.toUpperCase()}`;if(birthday&&!sessionStorage.getItem('indu.birthday.shown')){sessionStorage.setItem('indu.birthday.shown','1');setTimeout(()=>toast(`INDU has a birthday gift for ${name}. ✦`),500);}}
  loadNews(true);
  $("#refreshNews")?.addEventListener('click',()=>loadNews(true));
  const newsObserver=$("#newsSentinel"); if(newsObserver && 'IntersectionObserver' in window)new IntersectionObserver(es=>{if(es.some(e=>e.isIntersecting)&&newsOffset>0)loadNews(false)},{rootMargin:'600px'}).observe(newsObserver);
  setupBirthday();

  let currentQuery = "";
  let currentTab = "all";
  let suggestionTimer = null;
  async function doSearch(query, tab="all") {
    const q=query.trim();
    if(!q) return;
    currentQuery=q; currentTab=tab;
    const hist=safeJSON(DB.history,[]).filter(x=>x!==q); hist.unshift(q); save(DB.history,hist.slice(0,50));
    history.pushState({q,tab}, "", `/search?q=${encodeURIComponent(q)}&tab=${encodeURIComponent(tab)}`);
    await renderResults(q,tab);
  }
  $("#searchForm").addEventListener("submit",e=>{e.preventDefault();hideSuggestions();doSearch(qInput.value,currentTab||"all");});
  qInput.addEventListener("input",()=>{
    clearTimeout(suggestionTimer); const q=qInput.value.trim();
    if(!q){hideSuggestions();return;}
    suggestionTimer=setTimeout(async()=>{try{const r=await fetch(`/api/suggest?q=${encodeURIComponent(q)}`);const d=await r.json();const box=$("#suggestions");if(!d.suggestions?.length){hideSuggestions();return;}box.innerHTML=d.suggestions.map(s=>`<button type="button">${escapeHTML(s)}</button>`).join("");box.hidden=false;$$('button',box).forEach(b=>b.onclick=()=>{qInput.value=b.textContent;hideSuggestions();doSearch(b.textContent)});}catch{hideSuggestions();}},180);
  });
  qInput.addEventListener("keydown",e=>{if(e.key==="Escape")hideSuggestions();});
  function hideSuggestions(){const b=$("#suggestions");if(b)b.hidden=true;}
  document.addEventListener("click",e=>{if(!e.target.closest(".search-form"))hideSuggestions();});

  async function renderResults(q,tab="all") {
    currentQuery=q; currentTab=tab;
    [".news-card",".shortcut-card",".status-card"].forEach(s=>{const e=document.querySelector(s);if(e)e.style.display="none";});
    const home=document.querySelector(".home");
    let resultsBox=$("#resultsBox");
    if(!resultsBox){resultsBox=document.createElement("section");resultsBox.id="resultsBox";resultsBox.className="results-page";home.appendChild(resultsBox);}
    const tabs=[['ai','AI'],['all','ALL'],['images','IMAGES'],['videos','VIDEOS'],['short','SHORT VIDEOS'],['news','NEWS'],['shopping','SHOPPING']];
    resultsBox.innerHTML=`<div class="results-head"><button class="back" id="backHome" aria-label="Back">←</button><span>${escapeHTML(q)}</span><small>${escapeHTML(storage.getItem(DB.mode)||"AUTO")}</small></div><nav class="results-tabs" aria-label="Search categories">${tabs.map(([id,label])=>`<button class="result-tab ${id===tab?'active':''}" data-tab="${id}">${label}</button>`).join("")}</nav><div id="aiAnswerPanel"></div><div class="results-list"><div class="news-loading">Searching INDU…</div></div>`;
    $("#backHome").onclick=()=>location.href="/";
    $$(".result-tab",resultsBox).forEach(b=>b.onclick=()=>doSearch(q,b.dataset.tab));
    if(tab==="ai") return renderAIAnswer(q,resultsBox);
    if(tab==="news") return renderNewsResults(q,resultsBox);
    if(tab==="images"||tab==="videos"||tab==="short"||tab==="shopping") return renderSpecialTab(q,tab,resultsBox);
    try {
      const mode=storage.getItem(DB.mode)||"AUTO";
      const res=await fetch(`/api/search?q=${encodeURIComponent(q)}&mode=${encodeURIComponent(mode)}&limit=30`);
      const data=await res.json(); const list=$(".results-list",resultsBox);
      if(!data.results?.length){list.innerHTML=`<div class="empty-results"><h3>No indexed results yet</h3><p>INDU can search its independent D1 index and can optionally use a federated provider while Gugata grows the index.</p><div class="result-actions"><button class="primary" id="askNoResult">ASK INDU AI</button></div></div>`;$("#askNoResult")?.addEventListener("click",()=>doSearch(q,"ai"));return;}
      list.innerHTML=data.results.map(r=>`<article class="result"><div class="result-url">${escapeHTML(r.domain||r.url)}${r.source?` · ${escapeHTML(r.source)}`:""}</div><a href="${escapeHTML(r.url)}" target="_blank" rel="noopener noreferrer"><h2>${escapeHTML(r.title||r.url)}</h2></a><p>${escapeHTML(r.snippet||r.description||"")}</p></article>`).join("");
      const total=Number(data.meta?.total||0), page=Number(data.page||1), limit=Number(data.limit||30);
      if(total>page*limit){const more=document.createElement("div");more.className="result-actions";more.innerHTML=`<button class="secondary" id="nextResults">NEXT RESULTS</button>`;list.appendChild(more);$("#nextResults").onclick=async()=>{const r=await fetch(`/api/search?q=${encodeURIComponent(q)}&mode=${encodeURIComponent(mode)}&limit=${limit}&page=${page+1}`);const d=await r.json();list.innerHTML+=d.results.map(x=>`<article class="result"><div class="result-url">${escapeHTML(x.domain||x.url)}</div><a href="${escapeHTML(x.url)}" target="_blank" rel="noopener noreferrer"><h2>${escapeHTML(x.title||x.url)}</h2></a><p>${escapeHTML(x.snippet||x.description||"")}</p></article>`).join("");more.remove();};}
      if(data.protection?.threats){stats.threats+=data.protection.threats;save(DB.stats,stats);renderStats();}
    } catch { $(".results-list",resultsBox).innerHTML=`<div class="empty-results"><h3>INDU could not reach the search service</h3><p>Check the connection and try again.</p></div>`; }
  }
  async function renderAIAnswer(q,box){
    const panel=$("#aiAnswerPanel",box),list=$(".results-list",box);list.innerHTML=`<div class="news-loading">INDU AI is researching the indexed web…</div>`;
    try{
      const sr=await fetch(`/api/search?q=${encodeURIComponent(q)}&mode=${encodeURIComponent(storage.getItem(DB.mode)||"AUTO")}&limit=8`);
      const sd=await sr.json();
      const sources=(sd.results||[]).map(r=>({title:r.title,url:r.url,snippet:r.snippet||r.description}));
      const r=await fetch("/api/ai",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({prompt:`Answer this search query as INDU AI. Give the direct answer first, then a concise explanation. Query: ${q}`,sources})});
      const d=await r.json();
      const sourceHtml=(d.sources||sources).map((s,i)=>`<a class="ai-source" href="${escapeHTML(s.url)}" target="_blank" rel="noopener noreferrer">[${i+1}] ${escapeHTML(s.title||s.url)}</a>`).join("");
      panel.innerHTML=`<article class="ai-search-card"><div class="ai-badge">INDU AI</div><div class="ai-result">${escapeHTML(d.answer||d.error||"No AI answer returned.")}</div>${sourceHtml?`<div class="ai-sources"><b>SOURCES</b>${sourceHtml}</div>`:""}</article>`;
      list.innerHTML=`<div class="ai-followup"><button class="secondary" id="aiAll">VIEW WEB RESULTS</button></div>`;$("#aiAll")?.addEventListener("click",()=>doSearch(q,"all"));
    }catch{list.innerHTML=`<div class="empty-results">INDU AI is temporarily unavailable.</div>`;}
  }
  async function renderNewsResults(q,box){
    const list=$(".results-list",box);list.innerHTML=`<div class="news-loading">Finding news…</div>`;
    try{const r=await fetch(`/api/news?offset=0&limit=30`),d=await r.json();const terms=q.toLowerCase().split(/\s+/).filter(Boolean);const items=(d.items||[]).filter(n=>terms.some(t=>(n.title+" "+(n.description||"")).toLowerCase().includes(t)));if(!items.length){list.innerHTML=`<div class="empty-results">No matching indexed news stories.</div>`;return}list.innerHTML=items.map(n=>`<article class="result"><div class="result-url">${escapeHTML(n.source||"INDU News")}</div><a href="${escapeHTML(n.url)}" target="_blank" rel="noopener noreferrer"><h2>${escapeHTML(n.title)}</h2></a><p>${escapeHTML(n.description||"")}</p></article>`).join("");}catch{list.innerHTML=`<div class="empty-results">News is temporarily unavailable.</div>`;}
  }
  async function renderSpecialTab(q,tab,box){
    const list=$(".results-list",box);const labels={images:"Image",videos:"Video",short:"Short video",shopping:"Shopping"};
    try{
      if(tab==="images"||tab==="videos"||tab==="short"){
        const type=tab==="images"?"image":"video";const r=await fetch(`/api/media?q=${encodeURIComponent(q)}&type=${type}&limit=30`),d=await r.json();
        if(!d.items?.length){list.innerHTML=`<div class="empty-results"><h3>No indexed ${labels[tab].toLowerCase()} results yet</h3><p>INDU builds its media index as permitted pages are crawled.</p></div>`;return;}
        list.innerHTML=d.items.map(x=>`<article class="result media-result">${x.type==="image"?`<img loading="lazy" src="${escapeHTML(x.url)}" alt="${escapeHTML(x.alt||x.title||"")}">`:``}<div class="result-url">${escapeHTML(x.domain||x.url)}</div><a href="${escapeHTML(x.page_url||x.url)}" target="_blank" rel="noopener noreferrer"><h2>${escapeHTML(x.title||x.alt||x.page_url||x.url)}</h2></a><p>${escapeHTML(x.alt||x.page_url||"")}</p></article>`).join("");return;
      }
      const r=await fetch(`/api/search?q=${encodeURIComponent(q+" Shopping")}&mode=AUTO&limit=20`),d=await r.json();if(!d.results?.length){list.innerHTML=`<div class="empty-results"><h3>No shopping results in the current index</h3><p>Shopping results depend on indexed commerce pages or a configured provider.</p></div>`;return}list.innerHTML=d.results.map(x=>`<article class="result"><div class="result-url">${escapeHTML(x.domain||x.url)}</div><a href="${escapeHTML(x.url)}" target="_blank" rel="noopener noreferrer"><h2>${escapeHTML(x.title||x.url)}</h2></a><p>${escapeHTML(x.snippet||x.description||"")}</p></article>`).join("");
    }catch{list.innerHTML=`<div class="empty-results">Category search unavailable.</div>`;}
  }
  // INDU Lens: Camera or Clip, then action. Media never leaves the device until the user submits an action.
  async function fileToDataURL(file){return await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(file);});}
  async function videoFrames(file,count=4){return await new Promise((resolve,reject)=>{const v=document.createElement("video");v.muted=true;v.playsInline=true;const u=URL.createObjectURL(file);v.src=u;v.onloadedmetadata=async()=>{try{const duration=Math.max(.1,v.duration||.1),out=[];for(let i=0;i<count;i++){const t=Math.min(duration-.05,(duration*(i+1))/(count+1));await new Promise((res,rej)=>{const done=()=>{v.removeEventListener('seeked',done);res()};v.addEventListener('seeked',done,{once:true});v.currentTime=t;setTimeout(()=>{v.removeEventListener('seeked',done);rej(new Error('seek timeout'))},3000)});const c=document.createElement("canvas");c.width=Math.min(v.videoWidth||1280,1280);c.height=Math.round(c.width*(v.videoHeight||720)/(v.videoWidth||1280));c.getContext("2d").drawImage(v,0,0,c.width,c.height);out.push(c.toDataURL("image/jpeg",.78));}URL.revokeObjectURL(u);resolve(out)}catch(e){URL.revokeObjectURL(u);reject(e)}};v.onerror=()=>{URL.revokeObjectURL(u);reject(new Error("Could not read video"));};});}
  function openLens(){
    openModal(`<div class="modal-head"><h2>INDU LENS</h2><button class="close" data-close>×</button></div><div class="lens-choice"><button class="primary" id="lensCamera">CAM</button><button class="secondary" id="lensClip">CLIP</button></div><div id="lensStage" class="lens-stage"><p class="muted">Choose CAM or CLIP.</p></div>`);
    $("#lensCamera").onclick=async()=>{const stage=$("#lensStage");try{const stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:"environment"},audio:false});stage.innerHTML=`<video id="lensVideo" autoplay playsinline></video><button class="primary" id="captureLens">CAPTURE</button>`;const v=$("#lensVideo");v.srcObject=stream;$("#captureLens").onclick=async()=>{const c=document.createElement("canvas");c.width=v.videoWidth||1280;c.height=v.videoHeight||720;c.getContext("2d").drawImage(v,0,0,c.width,c.height);stream.getTracks().forEach(t=>t.stop());showLensActions(c.toDataURL("image/jpeg",.86));};}catch(e){stage.innerHTML=`<p class="muted">Camera permission was unavailable. You can use CLIP instead.</p>`;}};
    $("#lensClip").onclick=()=>{const stage=$("#lensStage");stage.innerHTML=`<label class="file-pick">SELECT CLIP<input id="lensFile" type="file" accept="video/*"></label><p class="muted">INDU uses a representative frame for the vision request in this build.</p>`;$("#lensFile").onchange=async e=>{const f=e.target.files[0];if(!f)return;if(f.size>80_000_000){toast("Clip is too large");return;}try{showLensActions((await videoFrames(f,4)));}catch{toast("Could not read clip");}};};
  }
  function showLensActions(imageDataUrl){
    const frames=Array.isArray(imageDataUrl)?imageDataUrl:[imageDataUrl]; const primary=frames[0];
    modalContent.innerHTML=`<div class="modal-head"><h2>INDU LENS</h2><button class="close" data-close>×</button></div><img class="lens-image" src="${primary}" alt="Lens capture"><div class="lens-actions">${["SOLVE","SELECT TEXT","TRANSLATE","AI","SEARCH","EXPLAIN","IDENTIFY","SUMMARIZE"].map(a=>`<button class="secondary lens-action-btn" data-action="${a}">${a}</button>`).join("")}</div><form id="lensQuestion" class="settings-form"><label>YOUR QUESTION<input name="question" maxlength="500" placeholder="Ask INDU anything about this image"></label><button class="primary" type="submit">ASK</button></form><div id="lensAnswer" class="ai-result"></div>`;
    const run=async(action,question="")=>{const out=$("#lensAnswer");out.textContent="INDU Lens is analyzing…";try{const r=await fetch("/api/lens",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({action,question,imageDataUrl:primary,imageDataUrls:frames})});const d=await r.json();out.textContent=d.answer||d.error||"No answer returned.";}catch{out.textContent="Lens is temporarily unavailable.";}};
    $$(".lens-action-btn",modalContent).forEach(b=>b.onclick=()=>run(b.dataset.action));$("#lensQuestion").onsubmit=e=>{e.preventDefault();run("AI",e.target.question.value.trim());};
  }
  $("#lensBtn").addEventListener("click",openLens);
  $("#aiBtn").addEventListener("click",()=>{const q=qInput.value.trim();if(q)doSearch(q,"ai");else{qInput.focus();toast("Enter a question for INDU AI");}});
  $("#kiteBtn").addEventListener("click",()=>location.href="/kite.html");
  $("#voiceBtn").addEventListener("click",()=>{const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){toast("Voice search is not supported by this browser");return;}const r=new SR();r.lang=navigator.language||"en-IN";r.interimResults=false;r.maxAlternatives=1;r.onstart=()=>toast("Listening…");r.onerror=()=>toast("Voice search unavailable");r.onresult=e=>{qInput.value=e.results[0][0].transcript;doSearch(qInput.value,"all")};r.start();});

  window.addEventListener("popstate",()=>location.reload());

  // Offline
  window.addEventListener("online",()=>toast("INDU is online"));
  window.addEventListener("offline",()=>toast("Offline — INDU Kite is available"));
  if("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(()=>{});

  const params=new URLSearchParams(location.search);
  if(params.get("q")) { qInput.value=params.get("q"); renderResults(params.get("q")); }
})();
