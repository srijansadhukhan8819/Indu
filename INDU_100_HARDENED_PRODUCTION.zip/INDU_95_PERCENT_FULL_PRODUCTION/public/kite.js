(()=>{
'use strict';
const canvas=document.getElementById('game'),ctx=canvas.getContext('2d');
const replay=document.getElementById('replayLogo'),overEl=document.getElementById('gameOver'),finalEl=document.getElementById('finalScore');
const hiEl=document.getElementById('hi'),scoreEl=document.getElementById('score');
const W=canvas.width,H=canvas.height,G=H-54;
const dark=matchMedia('(prefers-color-scheme: dark)').matches;
const C={bg:dark?'#0a0c0f':'#ffffff',fg:dark?'#f2f3f5':'#111820',muted:dark?'#8d96a2':'#7a838c',saffron:'#f59a17',green:'#72bf2f',blue:'#19325f'};
let best=Number(localStorage.getItem('indu_kite_best')||0)||0;
let state='ready',score=0,frame=0,speed=4,ground=0,nextSpawn=95,shake=0,lastMilestone=0,paused=false;
const kite={x:170,y:160,vy:0,size:22,gravity:.16,lift:-3.45,maxFall:6.2};
let obstacles=[],clouds=[],sparkles=[];
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
function init(){clouds=Array.from({length:7},()=>({x:Math.random()*W,y:35+Math.random()*105,s:.55+Math.random()*.95,v:.12+Math.random()*.28}));sparkles=Array.from({length:28},()=>({x:Math.random()*W,y:Math.random()*(G-15),a:.2+Math.random()*.5,p:Math.random()*7}));reset();}
function reset(){state='ready';score=0;frame=0;speed=4;ground=0;nextSpawn=95;shake=0;lastMilestone=0;paused=false;obstacles=[];kite.x=170;kite.y=160;kite.vy=0;overEl.hidden=true;replay.hidden=true;}
function start(){if(state==='over')reset();state='playing';paused=false;}
function flap(){if(state==='over'){start();kite.vy=kite.lift;return}if(state==='ready')start();if(state==='playing'&&!paused)kite.vy=kite.lift;}
addEventListener('keydown',e=>{if(e.code==='Space'||e.code==='ArrowUp'){e.preventDefault();flap()} if(e.code==='KeyP'){paused=!paused;}});
canvas.addEventListener('pointerdown',e=>{e.preventDefault();flap()},{passive:false});
replay.addEventListener('click',e=>{e.stopPropagation();start();kite.vy=kite.lift;});
function spawn(){const r=Math.random();if(r<.42){obstacles.push({t:'bird',x:W+30,y:65+Math.random()*150,w:42,h:22,p:Math.random()*10})}else if(r<.78){const gap=68,g=42+Math.random()*(G-120);obstacles.push({t:'thread',x:W+30,w:5,g,gh:gap})}else{const h=36+Math.random()*55;obstacles.push({t:'roof',x:W+30,y:G-h,w:48,h})}nextSpawn=Math.max(48,92-Math.min(frame/1600,1)*32+Math.random()*38)}
function hit(o){const r={x:kite.x-10,y:kite.y-10,w:20,h:20};if(o.t==='thread'){if(r.x+r.w<=o.x||r.x>=o.x+o.w)return false;return r.y<=o.g||r.y+r.h>=o.g+o.gh}return r.x<o.x+o.w&&r.x+r.w>o.x&&r.y<o.y+o.h&&r.y+r.h>o.y}
function end(){state='over';best=Math.max(best,Math.floor(score));localStorage.setItem('indu_kite_best',String(best));finalEl.textContent=String(Math.floor(score)).padStart(5,'0');overEl.hidden=false;replay.hidden=false;shake=9}
function update(){frame++; if(paused)return;for(const c of clouds){c.x-=c.v*(state==='playing'?speed/4:1);if(c.x<-80)c.x=W+80}if(state!=='playing')return;speed=4+Math.min(frame/900,3.8); const milestone=Math.floor(score/100); if(milestone>lastMilestone){lastMilestone=milestone; sparkles.push({x:W*.5,y:60+Math.random()*80,a:.9,p:frame*.01});} score+=.1+speed*.018;kite.vy=clamp(kite.vy+kite.gravity,-6.5,kite.maxFall);kite.y+=kite.vy;if(kite.y<25){kite.y=25;kite.vy=0}if(kite.y>G-10){kite.y=G-10;end();return}if(--nextSpawn<=0)spawn();for(let i=obstacles.length-1;i>=0;i--){const o=obstacles[i];o.x-=speed;if(o.x+(o.w||40)<-60){obstacles.splice(i,1);continue}if(hit(o)){end();break}}ground-=speed;if(ground<-48)ground+=48}
function roundRect(x,y,w,h,r){ctx.beginPath();ctx.roundRect(x,y,w,h,r);}
function cloud(c){ctx.save();ctx.globalAlpha=.18;ctx.strokeStyle=C.fg;ctx.lineWidth=2;ctx.beginPath();ctx.arc(c.x,c.y,10*c.s,0,Math.PI*2);ctx.arc(c.x+15*c.s,c.y-6*c.s,13*c.s,0,Math.PI*2);ctx.arc(c.x+31*c.s,c.y,10*c.s,0,Math.PI*2);ctx.stroke();ctx.restore()}
function drawBackground(){ctx.fillStyle=C.bg;ctx.fillRect(0,0,W,H);for(const s of sparkles){ctx.globalAlpha=s.a*(.6+.4*Math.sin(frame*.02+s.p));ctx.fillStyle=C.fg;ctx.fillRect(s.x,s.y,2,2)}ctx.globalAlpha=1;for(const c of clouds)cloud(c);}
function drawKite(){ctx.save();ctx.translate(kite.x,kite.y);ctx.rotate(clamp(kite.vy*.055,-.42,.42));ctx.shadowBlur=10;ctx.shadowColor=C.saffron;const grad=ctx.createLinearGradient(-15,-15,15,15);grad.addColorStop(0,C.saffron);grad.addColorStop(1,C.green);ctx.fillStyle=grad;ctx.beginPath();ctx.moveTo(0,-18);ctx.lineTo(15,0);ctx.lineTo(0,19);ctx.lineTo(-15,0);ctx.closePath();ctx.fill();ctx.shadowBlur=0;ctx.strokeStyle=C.bg;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(0,-17);ctx.lineTo(0,18);ctx.moveTo(-14,0);ctx.lineTo(14,0);ctx.stroke();ctx.strokeStyle=C.fg;ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(0,19);ctx.bezierCurveTo(-12,27,10,33,-3,43);ctx.stroke();ctx.beginPath();ctx.arc(-3,43,2,0,Math.PI*2);ctx.fillStyle=C.saffron;ctx.fill();ctx.restore()}
function drawObstacle(o){if(o.t==='bird'){const f=Math.sin((frame+o.p)*.35)*7;ctx.fillStyle=C.fg;ctx.beginPath();ctx.moveTo(o.x,o.y+11);ctx.quadraticCurveTo(o.x+21,o.y-f,o.x+42,o.y+11);ctx.quadraticCurveTo(o.x+21,o.y+4,o.x,o.y+11);ctx.fill();ctx.fillStyle=C.green;ctx.fillRect(o.x+18,o.y+8,4,4)}else if(o.t==='roof'){ctx.fillStyle=C.fg;ctx.beginPath();ctx.moveTo(o.x,G);ctx.lineTo(o.x+o.w/2,o.y);ctx.lineTo(o.x+o.w,G);ctx.closePath();ctx.fill();ctx.fillStyle=C.saffron;ctx.fillRect(o.x+o.w/2-3,o.y+10,6,10)}else{ctx.strokeStyle=C.saffron;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(o.x+2,0);ctx.lineTo(o.x+2,o.g);ctx.stroke();ctx.strokeStyle=C.green;ctx.beginPath();ctx.moveTo(o.x+2,o.g+o.gh);ctx.lineTo(o.x+2,H);ctx.stroke();ctx.fillStyle=C.fg;ctx.fillRect(o.x-2,o.g-2,9,4);ctx.fillRect(o.x-2,o.g+o.gh-2,9,4)}}
function drawGround(){ctx.strokeStyle=C.fg;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(0,G);ctx.lineTo(W,G);ctx.stroke();ctx.lineWidth=1;for(let x=ground;x<W;x+=48){ctx.beginPath();ctx.moveTo(x,G+1);ctx.lineTo(x+20,G+1);ctx.stroke()}}
function draw(){ctx.save();if(shake>0){ctx.translate((Math.random()-.5)*shake,(Math.random()-.5)*shake);shake*=.86}drawBackground();drawGround();for(const o of obstacles)drawObstacle(o);drawKite();ctx.restore();scoreEl.textContent=String(Math.floor(score)).padStart(5,'0');hiEl.textContent='HI '+String(best).padStart(5,'0');if(state==='ready'){ctx.fillStyle=C.fg;ctx.globalAlpha=.82;ctx.textAlign='center';ctx.font='700 15px monospace';ctx.fillText('SPACE OR TAP TO LAUNCH THE KITE',W/2,H/2+8);ctx.globalAlpha=1}}
function loop(){update();draw();requestAnimationFrame(loop)}
init();loop();
})();
