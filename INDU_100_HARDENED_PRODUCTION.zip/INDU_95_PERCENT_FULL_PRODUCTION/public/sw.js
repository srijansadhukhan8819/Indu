const CACHE="indu-v1-100-shell";
const ASSETS=["/","/index.html","/styles.css","/app.js","/kite.html","/kite.js","/kite.css","/manifest.json","/assets/indu-mark.svg","/assets/indu-replay.png","/assets/indu-logo.png"];
self.addEventListener("install",e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener("activate",e=>e.waitUntil(self.clients.claim()));
self.addEventListener("fetch",e=>{
  const u=new URL(e.request.url);
  if(u.origin!==location.origin) return;
  if(e.request.method!=="GET") return;
  if(u.pathname.startsWith("/api/")) return;
  e.respondWith(caches.match(e.request).then(cached=>cached||fetch(e.request).then(r=>{
    const copy=r.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));return r;
  }).catch(()=>caches.match("/kite.html"))));
});
