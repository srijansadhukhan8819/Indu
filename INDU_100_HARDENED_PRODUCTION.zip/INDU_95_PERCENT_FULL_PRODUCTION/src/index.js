const VERSION = '2.1.0-100';
const JSON_HEADERS = {
  'content-type':'application/json; charset=utf-8',
  'cache-control':'no-store',
  'x-content-type-options':'nosniff',
  'referrer-policy':'strict-origin-when-cross-origin',
  'permissions-policy':'camera=(self), microphone=(self), geolocation=()',
  'x-frame-options':'DENY'
};
const json=(data,status=200,extra={},env=null)=>{
  const origin=env?.ALLOWED_ORIGIN||'*';
  return new Response(JSON.stringify(data),{status,headers:{...JSON_HEADERS,...extra,'access-control-allow-origin':origin,'access-control-allow-methods':'GET,POST,OPTIONS','access-control-allow-headers':'Content-Type, Authorization'}});
};
const cleanText=(s,max=20000)=>String(s??'').replace(/\s+/g,' ').trim().slice(0,max);
const intEnv=(env,k,d,min=0,max=1e9)=>{const n=Number(env?.[k]);return Number.isFinite(n)?Math.min(max,Math.max(min,n)):d};
const sleep=ms=>new Promise(r=>setTimeout(r,Math.max(0,ms)));
const now=()=>Date.now();
const hostOf=u=>{try{return new URL(u).hostname.toLowerCase()}catch{return ''}};
const normalizeUrl=raw=>{const u=new URL(raw);if(!['http:','https:'].includes(u.protocol))throw new Error('Only HTTP/HTTPS URLs are allowed.');u.hash='';u.username='';u.password='';for(const k of [...u.searchParams.keys()]) if(/^utm_|^fbclid$|^gclid$|^mc_/.test(k.toLowerCase())) u.searchParams.delete(k);return u.toString()};
const sha256=async text=>{const d=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text));return [...new Uint8Array(d)].map(b=>b.toString(16).padStart(2,'0')).join('')};
const tokenize=q=>String(q||'').toLowerCase().replace(/[^\p{L}\p{N}\s-]+/gu,' ').split(/\s+/).filter(x=>x.length>1).slice(0,16);
function parseQuery(raw){
  let q=cleanText(raw,300),site='',intitle='',excluded=[];
  const phrases=[];
  q=q.replace(/"([^"\\]{1,120})"/g,(_,p)=>{phrases.push(p.trim());return ' ';});
  q=q.replace(/(?:^|\s)site:([^\s]+)/gi,(_,v)=>{site=v.toLowerCase();return ' ';});
  q=q.replace(/(?:^|\s)intitle:([^\s]+)/gi,(_,v)=>{intitle=v.toLowerCase();return ' ';});
  q=q.replace(/(?:^|\s)-([^\s]+)/g,(_,v)=>{excluded.push(v.toLowerCase());return ' ';});
  const terms=tokenize(q);
  const parts=[...phrases.map(p=>`"${p.replaceAll('"','""')}"`),...terms.map(t=>`"${t.replaceAll('"','""')}"`)];
  return {raw:cleanText(raw,300),site,intitle,excluded,phrases,terms,match:parts.length?`(${parts.join(' OR ')})`:null};
}
function domainMatches(domain,site){if(!site)return true;const s=site.replace(/^https?:\/\//,'').replace(/\/$/,'').toLowerCase();return domain===s||domain.endsWith('.'+s)}
function modeBoost(row,mode){const d=(row.domain||'').toLowerCase(),t=((row.title||'')+' '+(row.description||'')).toLowerCase();if(mode==='coding')return /github|gitlab|developer|docs|stackoverflow|npmjs|pypi|mdn/.test(d+t)?7:0;if(mode==='research')return /\.edu$|\.gov$|\.org$|arxiv|pubmed|nature|science|who\.int|ieee/.test(d+t)?7:0;if(mode==='cyber security')return /cve|nvd|owasp|security|mitre|cert|krebsonsecurity/.test(d+t)?8:0;if(mode==='news')return /news|today|latest|report|journal/.test(t)?5:0;return 0}
function freshness(row){const ts=Number(row.published_at||row.fetched_at||0);if(!ts)return 0;const days=Math.max(0,(Date.now()-ts)/86400000);return Math.max(0,4-Math.log1p(days)*1.15)}
function makeSnippet(text,q){const s=cleanText(text,5000),terms=tokenize(q);if(!s)return '';const low=s.toLowerCase();let at=-1;for(const t of terms){at=low.indexOf(t);if(at>=0)break}if(at<0)return s.slice(0,300)+(s.length>300?'…':'');const start=Math.max(0,at-110);return(start?'…':'')+s.slice(start,start+390)+(start+390<s.length?'…':'')}
function isPrivateHost(host){return /^(localhost|127\.|10\.|192\.168\.|169\.254\.|0\.0\.0\.0)/.test(host)||host.endsWith('.local')||host==='::1'||host.startsWith('fc')||host.startsWith('fd')}
function blockedDomain(host,env){const lists=[env.BLOCKED_DOMAINS,env.THREAT_DOMAINS].flatMap(x=>String(x||'').split(',')).map(x=>x.trim().toLowerCase()).filter(Boolean);return lists.some(d=>host===d||host.endsWith('.'+d))}
function safeFtsQuery(parsed){return parsed.match}
function normalizeMode(mode){const m=String(mode||'auto').toLowerCase().replace(/[_-]+/g,' ');return ['auto','research','coding','cyber security','news','shopping'].includes(m)?m:'auto'}
function queryVariants(parsed){
  const variants=[parsed.raw];
  if(parsed.terms.length>1) variants.push(parsed.terms.join(' '));
  if(parsed.terms.length>2) variants.push(parsed.terms.slice(0,Math.min(6,parsed.terms.length)).join(' '));
  return [...new Set(variants.filter(Boolean))].slice(0,3);
}
function qualityScore(row){
  const words=Number(row.word_count||0), imp=Number(row.importance||0);
  const https=String(row.url||'').startsWith('https://')?0.8:0;
  const length=words>120&&words<12000?1.2:words>50?0.4:-0.8;
  const title=row.title?1.0:0;
  const desc=row.description?0.5:0;
  return Math.min(8,Math.max(-3,imp*.25+https+length+title+desc));
}
function diversityKey(row){return (row.domain||hostOf(row.url||'')).toLowerCase()}
function diversify(rows,limit){
  const out=[],counts=new Map();
  for(const r of rows){const d=diversityKey(r),n=counts.get(d)||0;if(n>=3)continue;counts.set(d,n+1);out.push(r);if(out.length>=limit)break}
  return out;
}
function spellVariants(q){
  return String(q||'').toLowerCase().replace(/[^\p{L}\p{N}\s-]/gu,' ').split(/\s+/).filter(Boolean).map(x=>x.replace(/(.)\1{2,}/g,'$1$1')).join(' ');
}
function resultTypeBoost(row,mode){
  const u=String(row.url||'').toLowerCase(),d=String(row.domain||'').toLowerCase(),t=(String(row.title||'')+' '+String(row.description||'')).toLowerCase();
  if(mode==='shopping'&&/price|shop|buy|product|store|amazon|flipkart|myntra|walmart/.test(u+d+t))return 7;
  if(mode==='research'&&(/\.edu$|\.gov$|arxiv|pubmed|doi\.org|who\.int|nature\.com|science\.org/).test(d+t))return 5;
  if(mode==='coding'&&/github|gitlab|stackoverflow|npmjs|pypi|developer|docs|mdn/.test(d+t))return 5;
  return 0;
}
function rankScore(row,q,mode){const terms=tokenize(q);const title=(row.title||'').toLowerCase(),desc=(row.description||'').toLowerCase(),url=(row.url||'').toLowerCase();let s=Number(row.importance||0)*2.2+freshness(row)+modeBoost(row,mode)+qualityScore(row)+resultTypeBoost(row,mode)+Math.min(10,Number(row.link_score||0)*0.35)+Math.min(4,Number(row.learned_score||0));for(const t of terms){if(title===t)s+=14;else if(title.includes(t))s+=8;if(desc.includes(t))s+=2.4;if(url.includes(t))s+=1;if((row.text||'').toLowerCase().includes(t))s+=.2}if(/^https?:\/\//.test(row.url||''))s+=.15;return s}
async function localSearch(env,parsed,limit=20,offset=0,mode='auto'){
  if(!env.INDU_INDEX||!parsed.match)return {results:[],total:0};
  const clauses=['documents_fts MATCH ?','d.safe=1'];const binds=[parsed.match];
  if(parsed.site){clauses.push('(d.domain=? OR d.domain LIKE ?)');binds.push(parsed.site,`%.${parsed.site}`)}
  if(parsed.intitle){clauses.push('lower(d.title) LIKE ?');binds.push(`%${parsed.intitle}%`)}
  for(const x of parsed.excluded.slice(0,8)){clauses.push("lower(d.title||' '||d.description||' '||d.text) NOT LIKE ?");binds.push(`%${x.replaceAll('%','')}%`)}
  const where=clauses.join(' AND ');
  const count=await env.INDU_INDEX.prepare(`SELECT COUNT(*) n FROM documents_fts JOIN documents d ON d.id=documents_fts.rowid WHERE ${where}`).bind(...binds).first();
  const maxFetch=Math.min(Math.max((offset+limit)*8,100),800);
  const {results=[]}=await env.INDU_INDEX.prepare(`SELECT d.id,d.url,d.canonical_url,d.title,d.description,d.text,d.domain,d.fetched_at,d.published_at,d.importance,d.safe,d.word_count,bm25(documents_fts,10.0,5.0,1.0) rank,(SELECT score FROM url_rank_scores WHERE url=d.url) link_score,(SELECT AVG(weight) FROM learned_rank_signals WHERE url=d.url) learned_score FROM documents_fts JOIN documents d ON d.id=documents_fts.rowid WHERE ${where} LIMIT ? OFFSET ?`).bind(...binds,maxFetch,0).all();
  const rows=diversify(results.filter(r=>!blockedDomain(r.domain,env)).map(r=>({...r,_score:rankScore(r,parsed.raw,mode)-Number(r.rank||0)+Number(r.link_score||0)})).sort((a,b)=>b._score-a._score),Math.max(limit*3,limit));
  return {results:rows.slice(offset,offset+limit).map(({_score,text,...r})=>({...r,snippet:makeSnippet(text,parsed.raw)})),total:Number(count?.n||0)};
}
async function braveSearch(env,q,limit){
  if(!env.BRAVE_SEARCH_API_KEY)return [];
  const u=new URL('https://api.search.brave.com/res/v1/web/search');
  u.searchParams.set('q',q); u.searchParams.set('count',String(Math.min(limit,20)));
  u.searchParams.set('safesearch','strict'); if(env.DEFAULT_REGION)u.searchParams.set('country',env.DEFAULT_REGION);
  const ctl=new AbortController(); const timer=setTimeout(()=>ctl.abort(),intEnv(env,'SEARCH_PROVIDER_TIMEOUT_MS',4500,1000,10000));
  try{const r=await fetch(u,{signal:ctl.signal,headers:{accept:'application/json','x-subscription-token':env.BRAVE_SEARCH_API_KEY}});if(!r.ok)return [];const d=await r.json();return(d.web?.results||[]).filter(x=>x?.url&&!blockedDomain(hostOf(x.url),env)).map(x=>({url:x.url,title:x.title||x.url,description:cleanText(x.description||'',800),domain:hostOf(x.url),source:'Brave',published_at:x.age?Date.now():null,importance:0,safe:1,snippet:cleanText(x.description||'',380)}));}catch{return []}finally{clearTimeout(timer)}}
async function bingSearch(env,q,limit){
  if(!env.BING_SEARCH_API_KEY)return [];
  const u=new URL('https://api.bing.microsoft.com/v7.0/search');u.searchParams.set('q',q);u.searchParams.set('count',String(Math.min(limit,50)));u.searchParams.set('safeSearch','Strict');
  const ctl=new AbortController();const timer=setTimeout(()=>ctl.abort(),intEnv(env,'SEARCH_PROVIDER_TIMEOUT_MS',4500,1000,10000));
  try{const r=await fetch(u,{signal:ctl.signal,headers:{accept:'application/json','Ocp-Apim-Subscription-Key':env.BING_SEARCH_API_KEY}});if(!r.ok)return [];const d=await r.json();return(d.webPages?.value||[]).filter(x=>x?.url&&!blockedDomain(hostOf(x.url),env)).map(x=>({url:x.url,title:x.name||x.url,description:cleanText(x.snippet||'',800),domain:hostOf(x.url),source:'Bing',published_at:x.dateLastCrawled?Date.parse(x.dateLastCrawled):null,importance:0,safe:1,snippet:cleanText(x.snippet||'',380)}));}catch{return []}finally{clearTimeout(timer)}}
async function wikipediaSearch(q,limit=8){try{const u=new URL('https://en.wikipedia.org/w/api.php');u.searchParams.set('action','query');u.searchParams.set('list','search');u.searchParams.set('srsearch',q);u.searchParams.set('srlimit',String(Math.min(limit,10)));u.searchParams.set('format','json');u.searchParams.set('origin','*');const r=await fetch(u,{headers:{accept:'application/json'}});if(!r.ok)return[];const d=await r.json();return(d.query?.search||[]).map(x=>({url:`https://en.wikipedia.org/wiki/${encodeURIComponent(x.title.replaceAll(' ','_'))}`,title:x.title,description:cleanText(x.snippet?.replace(/<[^>]+>/g,'')||'',700),domain:'wikipedia.org',source:'Wikipedia',safe:1,importance:.4,snippet:cleanText(x.snippet?.replace(/<[^>]+>/g,'')||'',380)}));}catch{return[]}}
function mergeResults(groups,limit,query,mode,env){const seen=new Map();for(const r of groups.flat()){if(!r?.url)continue;const k=(r.canonical_url||r.url).toLowerCase();if(blockedDomain(hostOf(k),env))continue;const s=rankScore(r,query,mode);const old=seen.get(k);if(!old||s>old._mergeScore)seen.set(k,{...r,_mergeScore:s});}return [...seen.values()].sort((a,b)=>b._mergeScore-a._mergeScore).slice(0,limit).map(({_mergeScore,...r})=>r)}
async function search(env,q,mode,limit,page=1){
  const t0=now(),parsed=parseQuery(q),offset=(page-1)*limit;
  const local=await localSearch(env,parsed,limit,offset,mode);
  let results=local.results,total=local.total,source='INDU INDEX';
  const provider=String(env.SEARCH_PROVIDER||'local').toLowerCase();
  if(page===1 && (provider==='hybrid'||provider==='brave'||provider==='bing')){
    const calls=[];if(provider==='hybrid'||provider==='brave')calls.push(braveSearch(env,q,Math.min(limit,20)));if(provider==='hybrid'||provider==='bing')calls.push(bingSearch(env,q,Math.min(limit,20)));
    const external=mergeResults(await Promise.all(calls),Math.min(intEnv(env,'SEARCH_MERGE_RESULTS',24,1,50),limit+8),q,mode,env);
    if(external.length){results=mergeResults([local.results,external],limit,q,mode,env);total=Math.max(total,results.length);source=local.results.length?'INDU INDEX + FEDERATED':'FEDERATED';}
  }
  if(!results.length&&page===1){results=await wikipediaSearch(q,Math.min(8,limit));total=results.length;source='Wikipedia fallback'}
  const latency=now()-t0;
  if(env.INDU_INDEX&&env.TELEMETRY_ENABLED!=='false'){try{await env.INDU_INDEX.prepare('INSERT INTO search_events(query_hash,mode,provider,result_count,latency_ms,created_at) VALUES(?,?,?,?,?,?)').bind(await sha256(q.toLowerCase()),mode,source,results.length,latency,now()).run();}catch{}}
  return{results,total,source,latency,parsed:{site:parsed.site,intitle:parsed.intitle,excluded:parsed.excluded,phrases:parsed.phrases}}
}
async function recordFeedback(env,b){
  if(!env.INDU_INDEX)return false;
  const q=cleanText(b?.query,300),url=cleanText(b?.url,2000),action=cleanText(b?.action,32);
  if(!q||!url||!['click','helpful','not_helpful'].includes(action))return false;
  try{await env.INDU_INDEX.prepare('INSERT INTO query_feedback(query_hash,url,action,created_at) VALUES(?,?,?,?)').bind(await sha256(q.toLowerCase()),url,action,now()).run();await updateLearnedSignal(env,b);return true}catch{return false}
}
async function domainPolicy(env,domain){
  if(!env.INDU_INDEX)return null;
  const d=cleanText(domain,255).toLowerCase().replace(/^https?:\/\//,'').split('/')[0];
  if(!d)return null;
  return await env.INDU_INDEX.prepare('SELECT domain,crawl_allowed,search_allowed,safe,updated_at FROM domain_policies WHERE domain=?').bind(d).first();
}
async function suggestions(env,q){if(!env.INDU_INDEX||!cleanText(q,80))return[];const term=cleanText(q,80).toLowerCase();const {results=[]}=await env.INDU_INDEX.prepare(`SELECT title FROM documents WHERE lower(title) LIKE ? ORDER BY importance DESC,fetched_at DESC LIMIT 12`).bind(`${term}%`).all();return results.map(x=>x.title).filter(Boolean)}
function parseRobots(text,path){let groups=[],current=[];for(const raw of String(text||'').split(/\r?\n/)){const line=raw.split('#')[0].trim();if(!line)continue;const [k,...rest]=line.split(':');const key=k.toLowerCase(),v=rest.join(':').trim();if(key==='user-agent'){current=[v.toLowerCase()];groups.push({agents:current,allow:[],disallow:[]});}else if(groups.length&&(key==='allow'||key==='disallow')){const g=groups[groups.length-1];g[key].push(v)}}const applicable=groups.filter(g=>g.agents.includes('*')||g.agents.some(a=>a.includes('indu')));if(!applicable.length)return true;let allowed=true;for(const g of applicable){for(const p of g.disallow)if(p&&path.startsWith(p))allowed=false;for(const p of g.allow)if(p&&path.startsWith(p))allowed=true}return allowed}
async function robotsAllowed(url,env){const u=new URL(url),key=u.origin;if(env.INDU_INDEX){const c=await env.INDU_INDEX.prepare('SELECT robots,fetched_at FROM crawl_hosts WHERE host=?').bind(key).first();if(c&&Number(c.fetched_at)>Date.now()-86400000)return parseRobots(c.robots,u.pathname)}try{const r=await fetch(`${key}/robots.txt`,{headers:{'user-agent':'INDU-GugataBot/1.3 (+search engine crawler)'}});const text=r.ok?(await r.text()).slice(0,150000):'';if(env.INDU_INDEX)await env.INDU_INDEX.prepare(`INSERT INTO crawl_hosts(host,robots,fetched_at) VALUES(?,?,?) ON CONFLICT(host) DO UPDATE SET robots=excluded.robots,fetched_at=excluded.fetched_at`).bind(key,text,Date.now()).run();return parseRobots(text,u.pathname)}catch{return true}}
async function enqueue(env,urls,depth,priority=1){if(!env.INDU_INDEX||!urls.length)return;const now=Date.now();await env.INDU_INDEX.batch(urls.map(u=>env.INDU_INDEX.prepare(`INSERT INTO crawl_queue(url,depth,priority,discovered_at,status) VALUES(?,?,?,?, 'queued') ON CONFLICT(url) DO UPDATE SET priority=MAX(crawl_queue.priority,excluded.priority)`).bind(u,depth,priority,now)))}
async function discoverSitemap(env,origin){try{const r=await fetch(`${origin}/sitemap.xml`,{headers:{'user-agent':'INDU-GugataBot/1.3 (+search engine crawler)','accept':'application/xml,text/xml'}});if(!r.ok)return 0;const xml=(await r.text()).slice(0,1000000);const urls=[...xml.matchAll(/<loc>\s*([^<]+)\s*<\/loc>/gi)].map(m=>m[1].trim()).filter(Boolean).slice(0,Number(env.CRAWL_SITEMAP_LIMIT||500));await enqueue(env,urls,0,4);return urls.length}catch{return 0}}
async function crawlOne(env,rawUrl,depth=0){const url=normalizeUrl(rawUrl),host=hostOf(url);if(isPrivateHost(host))throw new Error('Private/local hosts are not crawlable.');if(blockedDomain(host,env))return{url,skipped:'blocked domain',links:[]};if(!(await robotsAllowed(url,env)))return{url,skipped:'robots.txt disallow',links:[]};const maxBytes=Number(env.CRAWL_MAX_BYTES||2000000);const r=await fetch(url,{redirect:'follow',headers:{'user-agent':'INDU-GugataBot/1.3 (+search engine crawler)','accept':'text/html,application/xhtml+xml','accept-encoding':'gzip, br'}});const type=(r.headers.get('content-type')||'').toLowerCase();if(!type.includes('text/html')&&!type.includes('application/xhtml+xml'))return{url,skipped:'not html',links:[]};const len=Number(r.headers.get('content-length')||0);if(len&&len>maxBytes)return{url,skipped:'too large',links:[]};let title='',description='',canonical='',bodyText='',lang='',robotsMeta='',publishedMeta='',links=[],media=[];const rw=new HTMLRewriter().on('html',{element(e){lang=e.getAttribute('lang')||''}}).on('title',{text(t){title+=t.text}}).on('meta',{element(e){const n=(e.getAttribute('name')||'').toLowerCase(),p=(e.getAttribute('property')||'').toLowerCase();if(n==='description'||p==='og:description')description=e.getAttribute('content')||description;if(n==='robots'||n==='googlebot')robotsMeta=(e.getAttribute('content')||'').toLowerCase();if(n==='date'||n==='article:published_time'||p==='article:published_time')publishedMeta=e.getAttribute('content')||publishedMeta}}).on('link',{element(e){const rel=(e.getAttribute('rel')||'').toLowerCase();if(rel.includes('canonical'))canonical=e.getAttribute('href')||'';if(rel.includes('nofollow'))e.removeAttribute('href')}}).on('body',{text(t){bodyText+=t.text}}).on('a',{element(e){const h=e.getAttribute('href'),rel=(e.getAttribute('rel')||'').toLowerCase();if(h&&!rel.includes('nofollow'))links.push(h)}}).on('img',{element(e){const h=e.getAttribute('src')||e.getAttribute('data-src');if(h)media.push({url:h,type:'image',alt:e.getAttribute('alt')||'',title:e.getAttribute('title')||''})}}).on('video',{element(e){const h=e.getAttribute('src');if(h)media.push({url:h,type:'video',alt:'',title:e.getAttribute('title')||''})}}).on('source',{element(e){const h=e.getAttribute('src');if(h)media.push({url:h,type:'video',alt:'',title:e.getAttribute('title')||''})}});await rw.transform(r).arrayBuffer();if(/(^|,|\s)(noindex)(,|\s|$)/.test(robotsMeta))return{url,skipped:'noindex',links:[]};bodyText=cleanText(bodyText,120000);title=cleanText(title,500)||host;description=cleanText(description,1000);const finalUrl=canonical?new URL(canonical,url).toString():url;const hash=await sha256(`${title}\n${description}\n${bodyText}`),words=bodyText?bodyText.split(/\s+/).length:0,publishedAt=Date.parse(publishedMeta)||null;const importance=Math.min(12,1+Math.log10(Math.max(words,10))/2+(new URL(finalUrl).pathname==='/'?2:0));if(env.INDU_INDEX)await env.INDU_INDEX.prepare(`INSERT INTO documents(url,canonical_url,title,description,text,domain,lang,fetched_at,published_at,status_code,content_hash,word_count,crawl_depth,importance,safe,robots_allowed) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(url) DO UPDATE SET canonical_url=excluded.canonical_url,title=excluded.title,description=excluded.description,text=excluded.text,domain=excluded.domain,lang=excluded.lang,fetched_at=excluded.fetched_at,status_code=excluded.status_code,content_hash=excluded.content_hash,word_count=excluded.word_count,crawl_depth=excluded.crawl_depth,importance=excluded.importance,safe=excluded.safe,robots_allowed=excluded.robots_allowed`).bind(url,finalUrl,title,description,bodyText,host,lang,Date.now(),publishedAt||null,r.status,hash,words,depth,importance,1,1).run();if(env.INDU_INDEX&&media.length){const rows=media.slice(0,100).map(m=>{try{return {...m,url:normalizeUrl(new URL(m.url,finalUrl).toString())}}catch{return null}}).filter(Boolean).filter(m=>!isPrivateHost(hostOf(m.url))&&!blockedDomain(hostOf(m.url),env));if(rows.length)await env.INDU_INDEX.batch(rows.map(m=>env.INDU_INDEX.prepare(`INSERT INTO media_assets(url,page_url,type,title,alt,domain,discovered_at,safe) VALUES(?,?,?,?,?,?,?,1) ON CONFLICT(url) DO UPDATE SET page_url=excluded.page_url,title=excluded.title,alt=excluded.alt,domain=excluded.domain,discovered_at=excluded.discovered_at`).bind(m.url,finalUrl,m.type,cleanText(m.title,300),cleanText(m.alt,500),hostOf(m.url),Date.now())))}const out=[],seen=new Set(),maxLinks=Number(env.CRAWL_MAX_LINKS||60),base=new URL(finalUrl);for(const href of links.slice(0,maxLinks)){try{const u=new URL(href,finalUrl);u.hash='';if(!['http:','https:'].includes(u.protocol)||isPrivateHost(u.hostname))continue;const s=normalizeUrl(u.toString());if(seen.has(s)||blockedDomain(hostOf(s),env))continue;seen.add(s);out.push(s)}catch{}}await enqueue(env,out,depth+1,Math.max(.5,3-depth*.25));if(depth===0)await discoverSitemap(env,base.origin);return{url,finalUrl,title,links:out.length,wordCount:words,lang,status_code:r.status,skipped:null}}
async function processQueue(env,limit=5){
  if(!env.INDU_INDEX)return[];
  const batch=Math.min(intEnv(env,'CRAWL_BATCH_SIZE',limit,1,25),limit);
  const cutoff=now()-intEnv(env,'CRAWL_RETRY_DELAY_MS',30000,1000,3600000);
  const {results=[]}=await env.INDU_INDEX.prepare("SELECT id,url,depth FROM crawl_queue WHERE status='queued' AND (last_attempt IS NULL OR last_attempt<?) ORDER BY priority DESC,discovered_at ASC LIMIT ?").bind(cutoff,batch).all();
  const out=[];
  for(const item of results){
    const claimed=await env.INDU_INDEX.prepare("UPDATE crawl_queue SET status='processing',last_attempt=?,attempts=attempts+1 WHERE id=? AND status='queued'").bind(now(),item.id).run();
    if(!claimed.success||Number(claimed.meta?.changes||0)!==1)continue;
    const t=now();
    try{const r=await crawlOne(env,item.url,Number(item.depth||0));await env.INDU_INDEX.prepare("UPDATE crawl_queue SET status='done' WHERE id=?").bind(item.id).run();await env.INDU_INDEX.prepare('INSERT INTO crawl_events(url,status,http_status,duration_ms,created_at) VALUES(?,?,?,?,?)').bind(item.url,r.skipped?'skipped':'indexed',r.status_code||null,now()-t,now()).run();out.push({url:item.url,ok:true,...r});}
    catch(e){const max=intEnv(env,'CRAWL_MAX_ATTEMPTS',4,1,20);await env.INDU_INDEX.prepare("UPDATE crawl_queue SET status=CASE WHEN attempts>=? THEN 'failed' ELSE 'queued' END WHERE id=?").bind(max,item.id).run();try{await env.INDU_INDEX.prepare('INSERT INTO crawl_events(url,status,http_status,duration_ms,created_at) VALUES(?,?,?,?,?)').bind(item.url,'error',null,now()-t,now()).run()}catch{}out.push({url:item.url,ok:false,error:String(e.message||e)});}
    await sleep(intEnv(env,'CRAWL_DELAY_MS',300,0,10000));
  }
  return out
}
async function ai(env,prompt,imageDataUrl='',sources=[],imageDataUrls=[]){
  if(!env.OPENROUTER_API_KEY)return{error:'INDU AI is not configured. Add OPENROUTER_API_KEY as a Cloudflare secret.'};
  const imgs=[...imageDataUrls.filter(Boolean).slice(0,6),...(imageDataUrl?[imageDataUrl]:[])].slice(0,6);
  const model=imgs.length?(env.OPENROUTER_VISION_MODEL||env.OPENROUTER_MODEL||'openrouter/free'):(env.OPENROUTER_MODEL||'openrouter/free');
  const sourceText=sources.slice(0,10).map((s,i)=>`[${i+1}] ${s.title||s.url}\n${s.url}\n${s.snippet||s.description||''}`).join('\n\n');
  const system='You are INDU AI by Gugata. Answer accurately and concisely. When sources are provided, ground claims in them and cite [1], [2], etc. Never invent sources, URLs, facts, or completed actions. State uncertainty. For images, distinguish observation from inference.';
  const content=imgs.length ? [{type:'text',text:cleanText(prompt,10000)}, ...imgs.map(u=>({type:'image_url',image_url:{url:String(u).slice(0,5000000)}}))] : `${cleanText(prompt,12000)}\n\nSEARCH SOURCES:\n${sourceText}`;
  const body={model,messages:[{role:'system',content:system},{role:'user',content}],temperature:.15,max_tokens:1800};
  const ctl=new AbortController();const timer=setTimeout(()=>ctl.abort(),15000);
  try{const r=await fetch('https://openrouter.ai/api/v1/chat/completions',{method:'POST',signal:ctl.signal,headers:{'content-type':'application/json','authorization':`Bearer ${env.OPENROUTER_API_KEY}`,'http-referer':env.PUBLIC_ORIGIN||'https://example.com','x-title':'INDU by Gugata'},body:JSON.stringify(body)});if(!r.ok)return{error:`AI provider returned HTTP ${r.status}.`};const d=await r.json();return{answer:d.choices?.[0]?.message?.content||'No answer returned.',model:d.model||model,sources:sources.slice(0,10).map((s,i)=>({n:i+1,title:s.title,url:s.url}))};}catch(e){return{error:e?.name==='AbortError'?'AI provider timed out.':'AI provider is temporarily unavailable.'}}finally{clearTimeout(timer)}}
async function ingestNews(env){if(!env.INDU_INDEX||!env.NEWS_RSS_URL)return{fetched:0};try{const r=await fetch(env.NEWS_RSS_URL,{headers:{accept:'application/rss+xml,application/atom+xml,application/xml,text/xml'}});if(!r.ok)return{fetched:0};const xml=(await r.text()).slice(0,2000000);const blocks=[...xml.matchAll(/<(item|entry)\b[\s\S]*?<\/(item|entry)>/gi)].map(m=>m[0]).slice(0,200);const clean=x=>cleanText(String(x||'').replace(/<!\[CDATA\[|\]\]>/g,'').replace(/<[^>]+>/g,''),1200);let n=0;for(const b of blocks){const get=tag=>{const m=b.match(new RegExp(`<${tag}[^>]*>([\s\S]*?)<\/${tag}>`,'i'));return m?clean(m[1]):''};const title=get('title'),description=get('description')||get('summary'),url=get('link')||((b.match(/<link[^>]+href=["']([^"']+)["']/i)||[])[1]||''),date=get('pubDate')||get('published')||get('updated');if(!title||!url)continue;const ts=Date.parse(date)||Date.now();const score=4+Math.max(0,3-Math.log1p(Math.max(0,(Date.now()-ts)/86400000)));await env.INDU_INDEX.prepare(`INSERT INTO news_cache(url,title,description,image_url,source,published_at,topics,score,fetched_at) VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(url) DO UPDATE SET title=excluded.title,description=excluded.description,published_at=excluded.published_at,score=excluded.score,fetched_at=excluded.fetched_at`).bind(normalizeUrl(url),title,description,null,hostOf(url),ts,'',score,Date.now()).run();n++;}return{fetched:n};}catch{return{fetched:0};}}
async function news(env,offset=0,limit=20){if(env.NEWS_FEED_URL)try{const r=await fetch(env.NEWS_FEED_URL,{headers:{accept:'application/json'}});if(r.ok){const d=await r.json();if(Array.isArray(d.items))return{items:d.items.map(n=>({...n,score:Number(n.score||0)+freshness(n)})).sort((a,b)=>b.score-a.score).slice(offset,offset+limit),hasMore:d.items.length>offset+limit}}}catch{}if(env.INDU_INDEX){const {results=[]}=await env.INDU_INDEX.prepare('SELECT url,title,description,image_url,source,published_at,topics,score FROM news_cache ORDER BY score DESC,published_at DESC LIMIT ? OFFSET ?').bind(limit,offset).all();return{items:results,hasMore:results.length===limit}}return{items:[],hasMore:false}}
async function mediaSearch(env,q,type='image',limit=30){if(!env.INDU_INDEX)return[];const terms=tokenize(q);const like=terms.length?terms.map(()=>'(lower(title) LIKE ? OR lower(alt) LIKE ? OR lower(page_url) LIKE ?)').join(' AND '):'1=1';const binds=terms.flatMap(t=>[`%${t}%`,`%${t}%`,`%${t}%`]);const {results=[]}=await env.INDU_INDEX.prepare(`SELECT url,page_url,type,title,alt,domain FROM media_assets WHERE type=? AND safe=1 AND ${like} ORDER BY discovered_at DESC LIMIT ?`).bind(type,...binds,limit).all();return results.filter(x=>!blockedDomain(x.domain,env))}

function rrfFuse(lists,limit=20){
  const scores=new Map(), items=new Map();
  for(const list of lists){
    list.forEach((row,i)=>{
      const key=(row.canonical_url||row.url||'').toLowerCase(); if(!key)return;
      scores.set(key,(scores.get(key)||0)+(1/(60+i+1)));
      if(!items.has(key))items.set(key,row);
    });
  }
  return [...scores.entries()].sort((a,b)=>b[1]-a[1]).slice(0,limit).map(([k,score])=>({...items.get(k),fusionScore:score}));
}
function languageHint(q){
  if(/[\u0980-\u09ff]/.test(q))return 'bn';
  if(/[\u0900-\u097f]/.test(q))return 'hi';
  if(/[\u0b80-\u0bff]/.test(q))return 'ta';
  if(/[\u0c00-\u0c7f]/.test(q))return 'te';
  return 'en';
}
function queryIntent(q,mode){
  const x=q.toLowerCase();
  if(/\b(how|steps|tutorial|guide)\b/.test(x))return 'howto';
  if(/\b(what|who|when|where|why)\b/.test(x))return 'fact';
  if(/\b(price|buy|shop|cost|deal|discount)\b/.test(x)||mode==='shopping')return 'shopping';
  if(/\b(code|api|sdk|javascript|python|sql|error|github)\b/.test(x)||mode==='coding')return 'coding';
  if(/\b(cve|exploit|vulnerability|malware|security)\b/.test(x)||mode==='cyber security')return 'security';
  if(/\b(latest|today|news|breaking|2026)\b/.test(x)||mode==='news')return 'news';
  return 'navigational';
}
function dedupeByContent(rows){const seen=new Set();return rows.filter(r=>{const k=String(r.content_hash||r.canonical_url||r.url||'').toLowerCase();if(!k||seen.has(k))return false;seen.add(k);return true})}
async function advancedSearch(env,q,mode,limit,page=1){
  const parsed=parseQuery(q), intent=queryIntent(q,mode), variant=experimentVariant('ranking-v2',q,['control','candidate']);
  const local=await localSearch(env,parsed,Math.min(80,limit*4),(page-1)*limit,mode);
  const providers=await Promise.all([braveSearch(env,q,Math.min(20,limit)),bingSearch(env,q,Math.min(20,limit)),wikipediaSearch(q,Math.min(8,limit))]);
  let fused=rrfFuse([local.results,...providers],Math.min(80,limit*4));
  const hints=entityHints(q);
  const reranked=fused.map((r,i)=>{let bonus=0;const txt=((r.title||'')+' '+(r.description||'')).toLowerCase();for(const h of hints)if(txt.includes(h.toLowerCase()))bonus+=2;if(intent==='news'&&freshness(r)>1)bonus+=2;if(variant==='candidate')bonus+=Math.min(3,Number(r.fusionScore||0)*4);return{...r,_score:Number(r.fusionScore||0)+bonus}}).sort((a,b)=>b._score-a._score);
  const enriched=dedupeByContent(reranked).map((r,i)=>({...r,position:i+1,language:languageHint(r.title+' '+(r.description||'')),intent}));
  await recordIntent(env,q,mode);
  return {results:enriched.slice(0,limit),total:Math.max(local.total,enriched.length),parsed,source:'hybrid-rrf-learned'};
}
async function relatedQueries(env,q,limit=8){
  if(!env.INDU_INDEX)return [];
  const terms=tokenize(q); if(!terms.length)return [];
  const like=`%${terms[0]}%`;
  const {results=[]}=await env.INDU_INDEX.prepare(`SELECT title FROM documents WHERE lower(title) LIKE ? ORDER BY importance DESC,fetched_at DESC LIMIT 40`).bind(like).all();
  const base=spellVariants(q), out=[];
  for(const r of results){const t=cleanText(r.title,100);if(!t||t.toLowerCase()===base.toLowerCase())continue;if(!out.includes(t))out.push(t);if(out.length>=limit)break}
  return out;
}
async function healthDeep95(env){
  const start=Date.now(), checks={version:VERSION};
  if(env.INDU_INDEX){
    try{const r=await env.INDU_INDEX.prepare('SELECT 1 AS ok').first();checks.database=!!r?.ok}catch{checks.database=false}
  }else checks.database=false;
  checks.ai=!!env.OPENROUTER_API_KEY; checks.brave=!!env.BRAVE_SEARCH_API_KEY; checks.bing=!!env.BING_SEARCH_API_KEY;
  checks.assets=!!env.ASSETS; checks.latencyMs=Date.now()-start;
  checks.ready=!!(checks.database&&checks.assets);
  return checks;
}
async function cacheGet(env,key){if(!env.INDU_INDEX)return null;const r=await env.INDU_INDEX.prepare('SELECT payload,expires_at FROM search_cache WHERE cache_key=?').bind(key).first();if(!r)return null;if(Number(r.expires_at)<Date.now()){await env.INDU_INDEX.prepare('DELETE FROM search_cache WHERE cache_key=?').bind(key).run();return null}try{return JSON.parse(r.payload)}catch{return null}}
async function cachePut(env,key,payload,ttl=300){if(!env.INDU_INDEX)return;await env.INDU_INDEX.prepare('INSERT INTO search_cache(cache_key,payload,expires_at,created_at) VALUES(?,?,?,?) ON CONFLICT(cache_key) DO UPDATE SET payload=excluded.payload,expires_at=excluded.expires_at').bind(key,JSON.stringify(payload).slice(0,500000),Date.now()+ttl*1000,Date.now()).run()}
async function abuseReport(env,b){if(!env.INDU_INDEX)return false;const url=cleanText(b.url,2000);if(!url)return false;await env.INDU_INDEX.prepare('INSERT INTO abuse_reports(url,reason,details,created_at,status) VALUES(?,?,?,?,?)').bind(url,cleanText(b.reason,120),cleanText(b.details,1000),Date.now(),'open').run();return true}
async function importCommonCrawlBatch(env,items=[]){
  if(!env.INDU_INDEX)return{imported:0,rejected:0,errors:0};
  const maxItems=intEnv(env,'COMMONCRAWL_IMPORT_BATCH',40,1,80),maxText=intEnv(env,'COMMONCRAWL_MAX_TEXT',100000,1000,180000);
  let imported=0,rejected=0,errors=0;const writes=[];
  for(const raw of Array.isArray(items)?items.slice(0,maxItems):[]){
    try{
      const url=normalizeUrl(cleanText(raw?.url,4000)),host=hostOf(url);
      if(!host||isPrivateHost(host)||blockedDomain(host,env)){rejected++;continue}
      const text=cleanText(raw?.text,maxText),title=cleanText(raw?.title,500)||host,description=cleanText(raw?.description,1000),canonical=raw?.canonical?normalizeUrl(raw.canonical):url;
      if(!text||raw?.noindex===true){rejected++;continue}
      const hash=cleanText(raw?.content_hash,128)||await sha256(`${title}\n${description}\n${text}`);
      const words=text.split(/\s+/).filter(Boolean).length;
      const lang=cleanText(raw?.lang,32),published=Number.isFinite(Number(raw?.published_at))?Number(raw.published_at):null;
      const importance=Math.min(12,1+Math.log10(Math.max(words,10))/2+(new URL(canonical).pathname==='/'?2:0));
      writes.push(env.INDU_INDEX.prepare(`INSERT INTO documents(url,canonical_url,title,description,text,domain,lang,fetched_at,published_at,status_code,content_hash,word_count,crawl_depth,importance,safe,robots_allowed) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(url) DO UPDATE SET canonical_url=excluded.canonical_url,title=excluded.title,description=excluded.description,text=excluded.text,domain=excluded.domain,lang=excluded.lang,fetched_at=excluded.fetched_at,published_at=excluded.published_at,status_code=excluded.status_code,content_hash=excluded.content_hash,word_count=excluded.word_count,importance=excluded.importance,safe=excluded.safe,robots_allowed=excluded.robots_allowed`).bind(url,canonical,title,description,text,host,lang,now(),published,200,hash,words,0,importance,1,1));
      imported++;
    }catch{errors++}
  }
  if(writes.length){for(let i=0;i<writes.length;i+=20)await env.INDU_INDEX.batch(writes.slice(i,i+20));}
  return{imported,rejected,errors};
}

function stableBucket(value,buckets=100){let h=0;for(const c of String(value||'')){h=((h<<5)-h+c.charCodeAt(0))|0}return Math.abs(h)%buckets}
function experimentVariant(name,key,variants=['control','candidate']){const i=stableBucket(`${name}:${key}`,variants.length);return variants[i]}
function entityHints(q){const raw=cleanText(q,300);const quoted=[...raw.matchAll(/"([^"\\]{2,100})"/g)].map(m=>m[1]);const caps=[...raw.matchAll(/\b[A-Z][\w-]{2,}(?:\s+[A-Z][\w-]{2,}){0,3}\b/g)].map(m=>m[0]);return [...new Set([...quoted,...caps])].slice(0,12)}
function recrawlClass(row){const words=Number(row.word_count||0),age=(Date.now()-Number(row.fetched_at||0))/86400000;if(age<1)return 'hot';if(age<7&&(words>500||Number(row.importance||0)>5))return 'warm';return 'cold'}
async function recordIntent(env,q,mode){if(!env.INDU_INDEX)return;try{const h=await sha256(q.toLowerCase());await env.INDU_INDEX.prepare(`INSERT INTO query_intents(query_hash,intent,language,confidence,seen_at) VALUES(?,?,?,?,?) ON CONFLICT(query_hash) DO UPDATE SET intent=excluded.intent,language=excluded.language,confidence=excluded.confidence,seen_at=excluded.seen_at`).bind(h,queryIntent(q,mode),languageHint(q),.9,now()).run()}catch{}}
async function recordSessionSignal(env,q,url,action='click'){if(!env.INDU_INDEX)return;try{const sh=await sha256(`${q}|${url||''}`);await env.INDU_INDEX.prepare(`INSERT INTO search_sessions(session_hash,query_count,click_count,last_query_at) VALUES(?,?,?,?) ON CONFLICT(session_hash) DO UPDATE SET query_count=query_count+1,click_count=click_count+?,last_query_at=?`).bind(sh,1,action==='click'?1:0,now(),action==='click'?1:0,now()).run()}catch{}}
async function updateLearnedSignal(env,b){if(!env.INDU_INDEX)return false;const q=cleanText(b?.query,300),url=cleanText(b?.url,2000),action=cleanText(b?.action,32);if(!q||!url)return false;const delta=action==='click'?1:action==='helpful'?2:action==='not_helpful'?-2:0;if(!delta)return false;try{await env.INDU_INDEX.prepare(`INSERT INTO learned_rank_signals(query_hash,url,signal,weight,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(query_hash,url) DO UPDATE SET signal=learned_rank_signals.signal+excluded.signal,weight=MIN(20,MAX(-20,learned_rank_signals.weight+excluded.weight)),updated_at=excluded.updated_at`).bind(await sha256(q.toLowerCase()),url,delta,delta,now()).run();await recordSessionSignal(env,q,url,action);return true}catch{return false}}
async function computeGraphScores(env){if(!env.INDU_INDEX)return{nodes:0,edges:0};const {results:docs=[]}=await env.INDU_INDEX.prepare('SELECT id FROM documents LIMIT 50000').all();const {results:deg=[]}=await env.INDU_INDEX.prepare(`SELECT to_url,COUNT(*) indegree FROM document_links GROUP BY to_url ORDER BY indegree DESC LIMIT 50000`).all();let n=0;for(const r of deg){const score=Math.min(100,Math.log1p(Number(r.indegree||0))*12);try{await env.INDU_INDEX.prepare('INSERT INTO url_rank_scores(url,score,updated_at) VALUES(?,?,?) ON CONFLICT(url) DO UPDATE SET score=excluded.score,updated_at=excluded.updated_at').bind(r.to_url,score,now()).run();n++}catch{}}return{nodes:docs.length,edges:deg.length,updated:n}}
async function refreshFreshness(env,limit=500){if(!env.INDU_INDEX)return{updated:0};const {results=[]}=await env.INDU_INDEX.prepare(`SELECT id,fetched_at,published_at,importance,word_count FROM documents ORDER BY fetched_at ASC LIMIT ?`).bind(limit).all();let updated=0;for(const r of results){const cls=recrawlClass(r);const next=cls==='hot'?6:cls==='warm'?24:72;try{await env.INDU_INDEX.prepare(`INSERT INTO freshness_schedule(document_id,next_crawl_at,class,updated_at) VALUES(?,?,?,?) ON CONFLICT(document_id) DO UPDATE SET next_crawl_at=excluded.next_crawl_at,class=excluded.class,updated_at=excluded.updated_at`).bind(r.id,now()+next*3600000,cls,now()).run();updated++}catch{}}return{updated}}
async function activateIndexVersion(env,versionId){if(!env.INDU_INDEX)return false;await env.INDU_INDEX.batch([env.INDU_INDEX.prepare("UPDATE index_versions SET status='ready' WHERE version_id=?").bind(versionId),env.INDU_INDEX.prepare("UPDATE index_versions SET status='active',activated_at=? WHERE version_id=?").bind(now(),versionId)]);return true}
async function createIndexVersion(env,notes=''){if(!env.INDU_INDEX)return null;const id=`idx-${Date.now()}-${Math.random().toString(36).slice(2,8)}`;await env.INDU_INDEX.prepare('INSERT INTO index_versions(version_id,status,documents,created_at,notes) VALUES(?,?,?,?,?)').bind(id,'building',0,now(),cleanText(notes,500)).run();return id}
async function globalHealth(env){const start=now(),m=await metrics(env);const checks={database:!!env.INDU_INDEX,assets:!!env.ASSETS,ai:!!env.OPENROUTER_API_KEY,searchProvider:!!(env.BRAVE_SEARCH_API_KEY||env.BING_SEARCH_API_KEY),cron:true,cache:!!env.INDU_INDEX,abuse:!!env.INDU_INDEX,ranking:!!env.INDU_INDEX};const passed=Object.values(checks).filter(Boolean).length;return{ok:passed===Object.keys(checks).length,version:VERSION,checks,score:`${passed}/${Object.keys(checks).length}`,index:m,latencyMs:now()-start}}
async function metrics(env){if(!env.INDU_INDEX)return{indexed:0,queued:0,failed:0,domains:0,media:0};const [a,b,c,d,e,f,g]=await Promise.all([env.INDU_INDEX.prepare('SELECT COUNT(*) n FROM documents').first(),env.INDU_INDEX.prepare("SELECT COUNT(*) n FROM crawl_queue WHERE status='queued'").first(),env.INDU_INDEX.prepare("SELECT COUNT(*) n FROM crawl_queue WHERE status='failed'").first(),env.INDU_INDEX.prepare('SELECT COUNT(DISTINCT domain) n FROM documents').first(),env.INDU_INDEX.prepare('SELECT COUNT(*) n FROM media_assets').first(),env.INDU_INDEX.prepare('SELECT COUNT(*) n FROM search_events WHERE created_at>?').bind(now()-86400000).first(),env.INDU_INDEX.prepare('SELECT AVG(latency_ms) n FROM search_events WHERE created_at>?').bind(now()-86400000).first()]);return{indexed:Number(a?.n||0),queued:Number(b?.n||0),failed:Number(c?.n||0),domains:Number(d?.n||0),media:Number(e?.n||0),searches24h:Number(f?.n||0),avgSearchLatencyMs:Math.round(Number(g?.n||0))}}
async function rateLimit(request,env){if(!env.INDU_INDEX)return true;const limit=Number(env.RATE_LIMIT_PER_MINUTE||120);const ip=request.headers.get('CF-Connecting-IP')||request.headers.get('x-forwarded-for')||'unknown';const bucket=Math.floor(Date.now()/60000);const key=await sha256(`${env.RATE_LIMIT_SALT||'indu-rate-limit'}:${ip}:${bucket}`);await env.INDU_INDEX.prepare(`INSERT INTO rate_limits(key,bucket,hits) VALUES(?,?,1) ON CONFLICT(key) DO UPDATE SET hits=hits+1`).bind(key,bucket).run();const row=await env.INDU_INDEX.prepare('SELECT hits FROM rate_limits WHERE key=?').bind(key).first();if(bucket%10===0)await env.INDU_INDEX.prepare('DELETE FROM rate_limits WHERE bucket<?').bind(bucket-5).run();return Number(row?.hits||0)<=limit}
async function protectionCheck(env,raw){try{const u=new URL(raw);const h=u.hostname.toLowerCase();return{url:u.toString(),domain:h,blocked:blockedDomain(h,env),private:isPrivateHost(h),https:u.protocol==='https:'};}catch{return{url:raw,blocked:true,invalid:true}}}
function isSameOrigin(request,env){const origin=env.ALLOWED_ORIGIN;return !origin||origin==='*'||new URL(request.url).origin===origin}
function adminOk(request,env){return !!env.ADMIN_CRAWL_TOKEN&&request.headers.get('authorization')===`Bearer ${env.ADMIN_CRAWL_TOKEN}`}
export default{async fetch(request,env){
  if(request.method==='OPTIONS')return new Response(null,{status:204,headers:{'access-control-allow-origin':env.ALLOWED_ORIGIN||'*','access-control-allow-methods':'GET,POST,OPTIONS','access-control-allow-headers':'Content-Type, Authorization','access-control-max-age':'86400'}});
  const url=new URL(request.url);
  const ratePaths=['/api/search','/api/suggest','/api/ai','/api/news','/api/media','/api/lens','/api/protection','/api/feedback','/api/related','/api/batch-search','/api/abuse-report','/api/health/deep'];
  if(ratePaths.includes(url.pathname)&&!(await rateLimit(request,env)))return json({error:'Rate limit exceeded. Please try again shortly.'},429,{'retry-after':'60'},env);
  if(url.pathname==='/health'){const m=await metrics(env);return json({ok:true,service:'INDU',product:'INDU Search',company:'Gugata',version:VERSION,time:new Date().toISOString(),index:m,ai:!!env.OPENROUTER_API_KEY,searchProvider:String(env.SEARCH_PROVIDER||'local')},200,{},env)}
  if(url.pathname==='/search')return env.ASSETS.fetch(new Request(new URL('/',request.url),request));
  if(url.pathname==='/api/health/deep'&&request.method==='GET'){
    const m=await metrics(env); const checks={db:!!env.INDU_INDEX,ai:!!env.OPENROUTER_API_KEY,provider:!!(env.BRAVE_SEARCH_API_KEY||env.BING_SEARCH_API_KEY),assets:!!env.ASSETS};
    return json({ok:Object.values(checks).filter(Boolean).length>=3,version:VERSION,checks,index:m},200,{},env);
  }
  if(url.pathname==='/api/query/normalize'&&request.method==='GET'){
    const raw=cleanText(url.searchParams.get('q'),300);const parsed=parseQuery(raw);const normalized=spellVariants(raw);return json({raw,normalized,operators:parsed,suggestions:[...new Set([raw,normalized,...queryVariants(parsed)])].slice(0,5)},200,{},env);
  }
  if(url.pathname==='/api/search'&&request.method==='GET'){const q=cleanText(url.searchParams.get('q'),intEnv(env,'MAX_QUERY_LENGTH',300,20,500));if(!q)return json({error:'Query is empty.',results:[]},400,{},env);const mode=normalizeMode(url.searchParams.get('mode')||'AUTO'),limit=Math.min(50,Math.max(1,Number(url.searchParams.get('limit')||20))),page=Math.min(100,Math.max(1,Number(url.searchParams.get('page')||1)));const normalized=spellVariants(q)||q;const key=await sha256(`${normalized}|${mode}|${page}|${limit}`);const cached=await cacheGet(env,key);if(cached)return json({...cached,meta:{...cached.meta,cache:'hit'}},200,{'cache-control':'public, max-age=30'},env);const t=Date.now();const data=await advancedSearch(env,normalized,mode,limit,page);const payload={query:q,normalized,mode,page,limit,results:data.results,meta:{count:data.results.length,total:data.total,indexed:env.INDU_INDEX?await env.INDU_INDEX.prepare('SELECT COUNT(*) n FROM documents').first().then(x=>Number(x?.n||0)):0,source:data.source,latencyMs:Date.now()-t,operators:data.parsed,intent:queryIntent(q,mode),language:languageHint(q)},protection:{ads:0,trackers:0,threats:0,shield:env.SHIELD_ENABLED!=='false'}};await cachePut(env,key,payload,Number(env.SEARCH_CACHE_TTL||30));return json(payload,200,{'cache-control':'public, max-age=30'},env)}
  if(url.pathname==='/api/suggest'&&request.method==='GET')return json({suggestions:await suggestions(env,cleanText(url.searchParams.get('q'),80))},200,{},env);
  if(url.pathname==='/api/ai'&&request.method==='POST'){try{const b=await request.json();const sources=Array.isArray(b.sources)?b.sources.filter(x=>x&&x.url).slice(0,10):[];const imgs=Array.isArray(b.imageDataUrls)?b.imageDataUrls.filter(Boolean).slice(0,6):[];return json(await ai(env,cleanText(b.prompt,12000),cleanText(b.imageDataUrl,5000000),sources,imgs),200,{},env)}catch{return json({error:'Invalid AI request.'},400,{},env)}}
  if(url.pathname==='/api/lens'&&request.method==='POST'){try{const b=await request.json();const action=cleanText(b.action||'AI',40);const prompt=cleanText(b.question||`Use the attached visual input to perform the Lens action: ${action}. For Select Text, transcribe visible text. For Translate, detect the source language and translate to English. For Solve, solve the visible problem step by step. For Identify, describe the subject and relevant facts. For Search, describe useful search terms.`,10000);const imgs=Array.isArray(b.imageDataUrls)?b.imageDataUrls.slice(0,6):[];return json(await ai(env,prompt,cleanText(b.imageDataUrl,5000000),[],imgs),200,{},env)}catch{return json({error:'Invalid Lens request.'},400,{},env)}}
  if(url.pathname==='/api/protection'&&request.method==='GET')return json(await protectionCheck(env,url.searchParams.get('url')||''),200,{},env);
  if(url.pathname==='/api/related'&&request.method==='GET'){const q=cleanText(url.searchParams.get('q'),200);return json({query:q,items:await relatedQueries(env,q,Math.min(12,Math.max(1,Number(url.searchParams.get('limit')||8))))},200,{},env)}
  if(url.pathname==='/api/batch-search'&&request.method==='POST'){try{const b=await request.json();const qs=Array.isArray(b.queries)?b.queries.slice(0,8).map(x=>cleanText(x,300)).filter(Boolean):[];const mode=normalizeMode(b.mode||'auto');const results=await Promise.all(qs.map(q=>advancedSearch(env,spellVariants(q)||q,mode,Math.min(20,Number(b.limit||10)),1)));return json({items:results.map((r,i)=>({query:qs[i],results:r.results,meta:{total:r.total,source:r.source}}))},200,{},env)}catch{return json({error:'Invalid batch search request.'},400,{},env)}}
  if(url.pathname==='/api/abuse-report'&&request.method==='POST'){try{return json({ok:await abuseReport(env,await request.json())},200,{},env)}catch{return json({ok:false,error:'Invalid abuse report.'},400,{},env)}}
  if(url.pathname==='/api/health/deep'&&request.method==='GET')return json(await healthDeep95(env),200,{},env);
  if(url.pathname==='/api/media'&&request.method==='GET'){const q=cleanText(url.searchParams.get('q'),200),type=['image','video'].includes(url.searchParams.get('type'))?url.searchParams.get('type'):'image',limit=Math.min(40,Math.max(1,Number(url.searchParams.get('limit')||20)));return json({items:await mediaSearch(env,q,type,limit),type},200,{},env)}
  if(url.pathname==='/api/news'&&request.method==='GET'){const offset=Math.max(0,Number(url.searchParams.get('offset')||0)),limit=Math.min(30,Math.max(1,Number(url.searchParams.get('limit')||20)));return json(await news(env,offset,limit),200,{},env)}
  if(url.pathname==='/api/metrics'&&request.method==='GET')return json(await metrics(env),200,{},env);
  if(url.pathname==='/api/feedback'&&request.method==='POST'){try{const b=await request.json();return json({ok:await recordFeedback(env,b)},200,{},env)}catch{return json({ok:false,error:'Invalid feedback.'},400,{},env)}}
  if(url.pathname==='/api/domain-policy'&&request.method==='GET'){return json({policy:await domainPolicy(env,url.searchParams.get('domain')||'')},200,{},env)}
  if(url.pathname==='/api/health/global'&&request.method==='GET')return json(await globalHealth(env),200,{},env);
  if(url.pathname==='/api/entities'&&request.method==='GET'){const q=cleanText(url.searchParams.get('q'),300);return json({query:q,entities:entityHints(q),intent:queryIntent(q,normalizeMode(url.searchParams.get('mode')||'auto')),language:languageHint(q)},200,{},env)}
  if(url.pathname==='/api/index/status'&&request.method==='GET'){if(!env.INDU_INDEX)return json({versions:[]},200,{},env);const {results=[]}=await env.INDU_INDEX.prepare('SELECT version_id,status,documents,created_at,activated_at,notes FROM index_versions ORDER BY created_at DESC LIMIT 20').all();return json({versions:results},200,{},env)}
  if(url.pathname==='/api/admin/graph-rebuild'&&request.method==='POST'){if(!adminOk(request,env))return json({error:'Unauthorized'},401,{},env);return json(await computeGraphScores(env),200,{},env)}
  if(url.pathname==='/api/admin/freshness-rebuild'&&request.method==='POST'){if(!adminOk(request,env))return json({error:'Unauthorized'},401,{},env);return json(await refreshFreshness(env,Math.min(5000,Number((await request.json().catch(()=>({}))).limit||500))),200,{},env)}
  if(url.pathname==='/api/admin/index-version'&&request.method==='POST'){if(!adminOk(request,env))return json({error:'Unauthorized'},401,{},env);const b=await request.json().catch(()=>({}));const id=await createIndexVersion(env,b.notes||'');return json({versionId:id},200,{},env)}
  if(url.pathname==='/api/admin/index-activate'&&request.method==='POST'){if(!adminOk(request,env))return json({error:'Unauthorized'},401,{},env);const b=await request.json().catch(()=>({}));return json({activated:await activateIndexVersion(env,cleanText(b.versionId,100))},200,{},env)}
  if(url.pathname==='/api/admin/import/commoncrawl'&&request.method==='POST'){if(!adminOk(request,env))return json({error:'Unauthorized'},401,{},env);try{const b=await request.json();return json(await importCommonCrawlBatch(env,b.items||[]),200,{},env)}catch{return json({error:'Invalid Common Crawl import payload.'},400,{},env)}}
  if(url.pathname==='/api/admin/crawl'&&request.method==='GET'){if(!adminOk(request,env))return json({error:'Unauthorized'},401,{},env);const raw=url.searchParams.get('url');if(!raw)return json({error:'Missing url'},400,{},env);try{return json(await crawlOne(env,raw,0),200,{},env)}catch(e){return json({error:String(e.message||e)},400,{},env)}}
  if(url.pathname==='/api/admin/seed-sitemap'&&request.method==='POST'){if(!adminOk(request,env))return json({error:'Unauthorized'},401,{},env);try{const b=await request.json();const n=await discoverSitemap(env,normalizeUrl(b.url).replace(/\/[^/]*$/,''));return json({queued:n},200,{},env)}catch(e){return json({error:String(e.message||e)},400,{},env)}}
  if(url.pathname==='/api/admin/process-queue'&&request.method==='POST'){if(!adminOk(request,env))return json({error:'Unauthorized'},401,{},env);return json({processed:await processQueue(env,intEnv(env,'CRAWL_BATCH_SIZE',8,1,25))},200,{},env)}
  if(url.pathname==='/api/admin/requeue-failed'&&request.method==='POST'){if(!adminOk(request,env))return json({error:'Unauthorized'},401,{},env);if(!env.INDU_INDEX)return json({requeued:0},200,{},env);const r=await env.INDU_INDEX.prepare("UPDATE crawl_queue SET status='queued' WHERE status='failed' AND attempts<?").bind(intEnv(env,'CRAWL_MAX_ATTEMPTS',4,1,20)).run();return json({requeued:Number(r.meta?.changes||0)},200,{},env)}
  if(url.pathname==='/api/admin/clear-index'&&request.method==='POST'){if(!adminOk(request,env))return json({error:'Unauthorized'},401,{},env);if(!env.INDU_INDEX)return json({cleared:false},200,{},env);await env.INDU_INDEX.batch(['documents_fts','documents','media_assets','crawl_queue'].map(t=>env.INDU_INDEX.prepare(`DELETE FROM ${t}`)));return json({cleared:true},200,{},env)}
  return env.ASSETS.fetch(request)
},async scheduled(event,env,ctx){ctx.waitUntil((async()=>{const seeds=String(env.CRAWL_SEEDS||'').split(',').map(s=>s.trim()).filter(Boolean);if(env.INDU_INDEX&&seeds.length)await enqueue(env,seeds.map(normalizeUrl),0,5);if(env.NEWS_RSS_URL)await ingestNews(env);await processQueue(env,intEnv(env,'CRAWL_BATCH_SIZE',8,1,25));await refreshFreshness(env,Number(env.FRESHNESS_BATCH_SIZE||100));if(env.GRAPH_REBUILD_ENABLED==='true')await computeGraphScores(env);})())}};
