# Provider Matrix

| Capability | Primary | Optional fallback |
|---|---|---|
| Web search | INDU D1 index | Brave/Bing |
| AI | OpenRouter | none |
| Lens | OpenRouter vision | none |
| News | D1 RSS cache | JSON feed |
| Images/videos | INDU media index | provider can be added without changing UI |
| Shopping | Indexed commerce pages | provider-specific integration |
