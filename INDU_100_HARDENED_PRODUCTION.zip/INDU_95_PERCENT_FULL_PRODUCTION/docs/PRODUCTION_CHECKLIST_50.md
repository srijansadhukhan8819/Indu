# INDU 50% Production Checklist

- [ ] D1 database created and migrations applied
- [ ] ALLOWED_ORIGIN and PUBLIC_ORIGIN set to the exact deployment origin
- [ ] ADMIN_CRAWL_TOKEN stored as a secret
- [ ] OpenRouter/provider keys stored as secrets only
- [ ] Crawl seeds reviewed and legally/technically permitted
- [ ] robots.txt compliance verified
- [ ] Rate limits tested
- [ ] Health endpoint checked
- [ ] Metrics endpoint checked
- [ ] Search feedback endpoint tested
- [ ] Failed crawl recovery tested
- [ ] Index backup/restore procedure documented outside the application
- [ ] Error monitoring and Cloudflare observability enabled
- [ ] Public beta load test completed before broad launch
