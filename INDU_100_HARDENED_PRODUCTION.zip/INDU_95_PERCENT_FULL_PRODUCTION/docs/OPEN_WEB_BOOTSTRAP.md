# INDU Open-Web Bootstrap

INDU now includes a production-oriented Common Crawl bootstrap path. Common Crawl publishes free web crawl data and a URL index; records can be retrieved efficiently using HTTP byte-range requests instead of downloading entire WARC files.

## 100 MB bootstrap mode

The supplied `scripts/commoncrawl-bootstrap.mjs` defaults to a **100 MiB compressed-record budget**. It:

1. Queries a selected Common Crawl URL Index archive.
2. Filters for HTTP 200 HTML records and collapses duplicate URL keys.
3. Fetches only each selected WARC record with a byte-range request.
4. Decompresses and extracts title, description, language, canonical URL and text.
5. Rejects obvious `noindex` pages, private hosts and configured blocked domains.
6. Sends sanitized records to `/api/admin/import/commoncrawl`.
7. Inserts into the same D1 + FTS5 index used by INDU search.

### Run

```bash
export INDU_BASE_URL=https://YOUR-INDU-DOMAIN
export INDU_CRAWL_TOKEN=YOUR_ADMIN_TOKEN
export COMMONCRAWL_INDEX=CC-MAIN-2026-25
export COMMONCRAWL_URL_FILTER='*.in/*'
npm run commoncrawl
```

For bulk Common Crawl workloads, do not hammer the CDX index. Common Crawl recommends caching/batching and using its bulk/columnar index products for large workloads.

## What this is—and is not

This is a bootstrap/augmentation pipeline, not a copy of the entire Common Crawl corpus. Current archives are multi-billion-page and hundreds-of-TiB datasets, so INDU should selectively ingest useful records and then use its own continuous crawler for freshness.

## Production controls

- 100 MiB default bootstrap budget
- configurable record/document limits
- slow, retrying requests with backoff
- descriptive User-Agent
- robots/noindex policy remains authoritative for INDU's own crawler
- private-host and domain block protections
- admin bearer-token protection on the import endpoint
- D1 batch writes capped to small groups
- FTS5 is populated through existing document triggers

Common Crawl source: https://commoncrawl.org/get-started
