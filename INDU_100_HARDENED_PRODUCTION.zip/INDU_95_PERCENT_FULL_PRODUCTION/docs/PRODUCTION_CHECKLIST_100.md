# INDU 100% Production Checklist

## Application
- [x] Search UI and search API
- [x] AI/VED answer layer
- [x] Lens
- [x] All / Images / Videos / Short-video foundations / News / Shopping foundations
- [x] Research / Coding / Cybersecurity / News / Shopping modes
- [x] Query operators and normalization
- [x] Related queries and suggestions
- [x] Result diversification and canonical deduplication

## Retrieval and ranking
- [x] Independent index
- [x] Hybrid provider adapters
- [x] Reciprocal-rank fusion
- [x] Quality/freshness/intent/vertical ranking
- [x] Link graph storage and graph-score rebuild
- [x] Learned feedback signals
- [x] Deterministic ranking experiments
- [x] Entity and knowledge-graph foundations

## Crawl/index operations
- [x] Robots.txt / sitemap / noindex / nofollow
- [x] Crawl queue and retry/backoff
- [x] Host state and lease foundations
- [x] Crawl budgets
- [x] Freshness scheduling
- [x] Canonical/content hash handling
- [x] Index versions and activation
- [x] Shard/region metadata

## Reliability/security
- [x] Rate limiting
- [x] Security headers/CSP
- [x] Private/local-host protection
- [x] Domain/threat blocking hooks
- [x] Abuse reporting
- [x] Search cache
- [x] Deep/global health checks
- [x] SLO telemetry foundations
- [x] Release metadata

## External launch requirements
- [ ] Production Cloudflare account/database configured
- [ ] Secrets configured
- [ ] Initial corpus seeded
- [ ] Continuous crawl bandwidth funded
- [ ] Relevance evaluation dataset established
- [ ] Legal/compliance review completed
- [ ] On-call/SRE ownership established

The final unchecked items are deployment/business prerequisites, not software stubs.


## Open-web bootstrap hardening
- [x] Common Crawl URL-index discovery
- [x] WARC byte-range retrieval
- [x] bounded 100 MiB bootstrap budget
- [x] sanitized Common Crawl import endpoint
- [x] admin authentication on import
- [x] private-host / blocked-domain protection
- [x] D1/FTS5 integration
- [ ] production crawl corpus and relevance evaluation still require operator-owned data, capacity, policy and legal review
