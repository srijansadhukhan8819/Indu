# INDU v1 architecture

## Request path

Browser search bar
→ `https://INDU_HOST/search?q=%s`
→ Cloudflare Worker
→ static INDU shell + `/api/search`
→ local D1 FTS5 index
→ optional external fallback
→ ranked results

## Components

### Frontend
Vanilla HTML/CSS/JavaScript keeps the initial payload small and avoids a mandatory build step.

### Worker
Routes API requests, validates input, applies rate-limit-friendly headers, calls D1, OpenRouter, news provider, and crawler logic.

### D1
Stores documents, crawl metadata, security events, shortcuts/config schemas if server-side features are later added, and an FTS5 virtual table for text retrieval.

### Crawler
The v1 crawler is intentionally conservative:
- HTTP/HTTPS only
- robots.txt checked
- content type must be HTML
- configurable byte cap
- canonical URL support
- metadata/title extraction
- link extraction
- no script execution
- no arbitrary file downloads
- same-origin preference for discovered links

### Future scale path
D1 FTS5 is appropriate for an early index. A much larger Gugata index should evolve toward sharded retrieval/index services, durable crawl queues, distributed fetch workers, deduplication, spam classification, link graph scoring, freshness scoring, and independent ranking infrastructure.

## Privacy

Canvas is local-only in v1. Local browser storage is used for profile/background settings. The server does not need Canvas DOB/name/background to render ordinary search.

## Theme

Theme is derived from `prefers-color-scheme`. There is deliberately no manual light/dark selector in the UI, matching the product requirement.
