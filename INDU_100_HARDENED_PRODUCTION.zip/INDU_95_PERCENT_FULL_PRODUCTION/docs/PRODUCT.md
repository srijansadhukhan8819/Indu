# INDU product specification

INDU is a search engine by Gugata. Users normally access it through a browser by saving INDU as their browser's search engine. The homepage is intentionally search-first and does not turn INDU into a browser.

The search bar follows the supplied visual reference: an Indian-inspired saffron-to-green gradient rail, INDU logo at the left, search field, Lens, AI, voice, Shield, and Kite actions. The logo opens a compact gradient control strip containing STATUS, MODES, CANVAS, and MORE SETTINGS, plus the momentary Shield toggle. The interface follows the device's system light/dark preference automatically; no theme option is exposed.

Canvas is a local personalization layer. The user can enter a name, date of birth, and other details. The page can greet the user by name while INDU remains permanently branded at the top-left. Background images and 10–15 second clips are stored locally in IndexedDB and are not uploaded by this package. Birthday state is also local.

Lens starts with exactly two acquisition choices: Camera or Clip. After an image/frame is available, the user gets visual actions and can enter a custom question. The AI endpoint can receive an image data URL for vision-capable OpenRouter models.

Below shortcuts is the gradient status bar. It is intended to show live search-layer estimates such as ads, trackers, and threats. These numbers must only be described as real measurements when a real detection provider is wired in; the UI does not fabricate Brave-equivalent browser blocking.

The news area is a continuously paginated feed. Ranking combines feed score, user topic preferences, freshness, and importance signals. It requires a configured news source or D1 news cache.

INDU Kite is the offline mini-game. It is inspired by the role of Chrome's offline game, but has its own kite mechanics and INDU branding. When the player loses, an INDU logo appears as the replay control; tapping it starts another game. The game also supports Space/ArrowUp and touch input.
