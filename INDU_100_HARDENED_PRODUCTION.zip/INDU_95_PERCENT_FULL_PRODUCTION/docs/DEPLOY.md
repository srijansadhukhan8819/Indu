# INDU deployment checklist

## 1. Cloudflare
Use Workers + Static Assets for this package. The `wrangler.jsonc` already defines the static asset directory and Worker entry point.

## 2. D1
Create a D1 database named `indu-index`, copy the database ID into `wrangler.jsonc`, then run:

```bash
npm install
npm run db:remote
```

## 3. Secrets
Set secrets from the Wrangler CLI:

```bash
wrangler secret put OPENROUTER_API_KEY
wrangler secret put ADMIN_CRAWL_TOKEN
```

Do not place secrets in HTML, JavaScript, `.env` files committed to git, or Cloudflare public variables.

## 4. Variables
Set `ALLOWED_ORIGIN` and `PUBLIC_ORIGIN` to the exact production origin. Keep `SEARCH_PROVIDER=local` if you want INDU's own D1 index to be authoritative. `SEARCH_PROVIDER=brave` is an optional external fallback and requires its own API key.

## 5. Crawl
Put a small set of high-quality public seed URLs into `CRAWL_SEEDS`. The Worker cron periodically adds seeds to the queue and processes a small batch. For large-scale indexing, use a dedicated crawler/indexer outside the free Worker execution path.

## 6. Custom search engine
In the user's browser, add INDU as a custom search engine with a query URL ending in `?q=%s`. INDU remains a search engine, not a browser.

## 7. Pre-launch checks
- Run syntax checks.
- Run tests.
- Run a local Wrangler dev server.
- Verify `/health`.
- Verify `/api/search?q=...` after D1 has indexed content.
- Verify `/api/ai` only after setting the server-side secret.
- Test Camera permission and Lens on HTTPS.
- Test Canvas media persistence on Android and desktop.
- Test INDU Kite on touch and keyboard.
- Test the offline shell by loading once online and then disabling connectivity.
- Test CSP/security headers.


## 80% build notes
The default `SEARCH_PROVIDER=local` keeps the independent D1 index authoritative. If you want temporary federated coverage, set `SEARCH_PROVIDER=brave` and add `BRAVE_SEARCH_API_KEY` as a secret. If neither returns results, INDU uses Wikipedia search as a limited public discovery fallback.

Never put API keys in `public/` or client-side JavaScript.
