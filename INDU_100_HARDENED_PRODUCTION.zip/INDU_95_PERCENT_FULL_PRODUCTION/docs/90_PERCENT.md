# INDU 90% milestone

## Search
INDU now supports `site:example.com`, `intitle:keyword`, quoted phrases, and `-excluded` terms. Results are ranked after FTS retrieval using title/description/URL matches, freshness, crawl importance and selected mode. Pagination is supported through the API.

## Indexing
The Worker crawler respects robots.txt, noindex and nofollow signals, normalizes tracking parameters, discovers sitemaps, extracts links, and records image/video assets. Crawl queue priorities and retry delays are configurable.

## AI
INDU AI receives the query plus a bounded set of indexed search sources. The model is instructed to cite those sources as `[1]`, `[2]`, etc. The browser never receives the OpenRouter secret.

## Lens
Camera or a selected clip can be converted into a vision request. The current 90% implementation uses a representative frame for clips rather than claiming full temporal video understanding.

## Protection
The search layer can filter configured blocked/threat domains and has short-lived hashed request rate limiting. This does **not** turn INDU into a browser-wide ad/tracker/malware blocker. Search engines cannot intercept arbitrary navigation performed by the user's browser.

## News
A configured RSS/Atom URL can be ingested into D1 on the Worker schedule. The feed is ranked by freshness and configured score. A JSON feed adapter remains available.

## Media
Images and video URLs discovered in permitted pages are indexed into `media_assets` and exposed through `/api/media`.

## 100% remaining
The next milestone focuses on distributed crawl/index infrastructure, stronger relevance evaluation, media/news quality, robust abuse detection, operational monitoring, and production-scale performance.
