# INDU Production Checklist

1. Create D1 and set `database_id`.
2. Run `npm run db:remote`, then `npm run db:90`, then `npm run db:100`.
3. Set `ALLOWED_ORIGIN` and `PUBLIC_ORIGIN`.
4. Set `OPENROUTER_API_KEY` secret.
5. Set `OPENROUTER_MODEL` and a vision-capable `OPENROUTER_VISION_MODEL`.
6. For broad web results, set `SEARCH_PROVIDER=hybrid` and add `BRAVE_SEARCH_API_KEY` and/or `BING_SEARCH_API_KEY` as secrets.
7. Configure `CRAWL_SEEDS` with permitted public sites.
8. Set a strong `ADMIN_CRAWL_TOKEN`.
9. Deploy with Wrangler.
10. Add INDU to the browser as a custom search engine using `https://YOUR-HOST/?q=%s`.
11. Verify `/health`, search, AI, Lens, News, Canvas, offline Kite and admin crawl operations.
12. Monitor D1 size, request limits, provider quotas, crawl errors and AI spend.
