const base = process.argv[2];
const token = process.env.INDU_CRAWL_TOKEN;
if (!base || !token) {
  console.error("Usage: INDU_CRAWL_TOKEN=... node scripts/crawl.mjs https://your-worker.workers.dev");
  process.exit(1);
}
const seeds = process.argv.slice(3);
if (!seeds.length) {
  console.error("Provide one or more seed URLs after the worker URL.");
  process.exit(1);
}
for (const seed of seeds) {
  const u = new URL("/api/admin/crawl", base);
  u.searchParams.set("url", seed);
  const r = await fetch(u, {headers:{authorization:`Bearer ${token}`}});
  console.log(seed, r.status, await r.text());
}
