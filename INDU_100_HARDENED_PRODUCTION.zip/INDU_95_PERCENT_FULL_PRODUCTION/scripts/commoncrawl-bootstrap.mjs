#!/usr/bin/env node
/**
 * INDU Open-Web Bootstrap: Common Crawl -> INDU admin importer.
 * Default hard cap: 100 MiB of compressed WARC range data.
 * Uses Common Crawl's URL Index to discover records and HTTP Range requests
 * to retrieve only selected WARC records. It does not mirror the corpus.
 */
import { gunzipSync } from 'node:zlib';

const base=process.env.INDU_BASE_URL||process.argv[2];
const token=process.env.INDU_CRAWL_TOKEN;
const crawl=process.env.COMMONCRAWL_INDEX||'CC-MAIN-2026-25';
const pattern=process.env.COMMONCRAWL_URL_FILTER||'*.in/*';
const maxBytes=Number(process.env.COMMONCRAWL_MAX_BYTES||104857600);
const maxRecords=Number(process.env.COMMONCRAWL_MAX_RECORDS||1000);
const delayMs=Number(process.env.COMMONCRAWL_DELAY_MS||750);
if(!base||!token){console.error('Usage: INDU_BASE_URL=https://... INDU_CRAWL_TOKEN=... node scripts/commoncrawl-bootstrap.mjs [worker-url]');process.exit(1)}
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const headers={'user-agent':'INDU-GugataBot/2.1 (+open-web bootstrap; contact Gugata)','accept':'application/json'};
function clean(s,n){return String(s??'').replace(/\s+/g,' ').trim().slice(0,n)}
function htmlMeta(html,name){const re=new RegExp(`<meta[^>]+(?:name|property)=["']${name}["'][^>]+content=["']([^"']*)["'][^>]*>`,`i`);return clean(html.match(re)?.[1]||'',1000)}
function first(re,s){return s.match(re)?.[1]||''}
function extract(html,url){
  const noindex=/meta[^>]+(?:name|property)=["'](?:robots|googlebot)["'][^>]+content=["'][^"']*noindex/i.test(html);
  if(noindex)return null;
  const canonical=first(/<link[^>]+rel=["'][^"']*canonical[^"']*["'][^>]+href=["']([^"']+)["']/i,html)||first(/<link[^>]+href=["']([^"']+)["'][^>]+rel=["'][^"']*canonical/i,html);
  const title=clean(first(/<title[^>]*>([\s\S]*?)<\/title>/i,html).replace(/<[^>]+>/g,' '),500);
  const description=htmlMeta(html,'description')||htmlMeta(html,'og:description');
  const lang=clean(first(/<html[^>]+lang=["']([^"']+)/i,html),32);
  const body=clean(html.replace(/<script[\s\S]*?<\/script>/gi,' ').replace(/<style[\s\S]*?<\/style>/gi,' ').replace(/<noscript[\s\S]*?<\/noscript>/gi,' ').replace(/<[^>]+>/g,' '),100000);
  if(body.length<80)return null;
  let final=url;try{if(canonical)final=new URL(canonical,url).toString()}catch{}
  return {url,title,description,lang,canonical:final,text:body};
}
function parseWarc(record){
  const marker='\r\n\r\n';let a=record.indexOf(marker);if(a<0){a=record.indexOf('\n\n');if(a<0)return null}else a+=4;
  const headers=record.slice(0,a);const payload=record.slice(a);
  if(!/^WARC\/1\.[01]/.test(headers))return null;
  const target=first(/^WARC-Target-URI:\s*(.+)$/im,headers);if(!target)return null;
  const httpAt=payload.search(/HTTP\/\d(?:\.\d)?\s+200\b/i);if(httpAt<0)return null;
  const html=payload.slice(httpAt);
  const sep=html.indexOf('\r\n\r\n');if(sep<0)return null;
  const httpBody=html.slice(sep+4);
  const ctype=first(/^content-type:\s*([^;\r\n]+)/im,html).toLowerCase();
  if(ctype&&!ctype.includes('text/html')&&!ctype.includes('application/xhtml'))return null;
  return {target,html:httpBody,digest:first(/^WARC-Payload-Digest:\s*(.+)$/im,headers)};
}
async function indexRecords(){
  const u=new URL(`https://index.commoncrawl.org/${crawl}-index`);u.searchParams.set('url',pattern);u.searchParams.set('output','json');u.searchParams.append('filter','status:200');u.searchParams.append('filter','mime:text/html');u.searchParams.set('collapse','urlkey');u.searchParams.set('limit',String(Math.min(maxRecords,5000)));
  for(let attempt=1;attempt<=5;attempt++){
    const r=await fetch(u,{headers});
    if(r.ok){const text=await r.text();return text.split(/\n/).map(x=>x.trim()).filter(Boolean).map(x=>JSON.parse(x)).slice(0,maxRecords)}
    if(r.status===429||r.status>=500){await sleep(1000*attempt);continue}
    throw new Error(`Common Crawl index HTTP ${r.status}: ${await r.text()}`)
  }
  throw new Error('Common Crawl index unavailable after retries');
}
async function fetchRecord(r){
  const offset=Number(r.offset),length=Number(r.length);if(!Number.isSafeInteger(offset)||!Number.isSafeInteger(length)||length<=0)return null;
  const end=offset+length-1;const u=`https://data.commoncrawl.org/${r.filename}`;
  for(let attempt=1;attempt<=5;attempt++){
    const res=await fetch(u,{headers:{'user-agent':headers['user-agent'],'range':`bytes=${offset}-${end}`}});
    if(res.ok||res.status===206){const buf=new Uint8Array(await res.arrayBuffer());try{return {buf,record:r}}catch{}}
    if(res.status===429||res.status>=500){await sleep(1000*attempt);continue}
    return null;
  }
  return null;
}
async function main(){
  console.log(`INDU Common Crawl bootstrap: ${crawl} pattern=${pattern} cap=${maxBytes} bytes`);
  const records=await indexRecords();console.log(`Index records selected: ${records.length}`);
  let used=0,ok=0,skip=0;
  const endpoint=new URL('/api/admin/import/commoncrawl',base).toString();
  for(const r of records){
    const len=Number(r.length||0);if(!len||used+len>maxBytes)break;
    const got=await fetchRecord(r);if(!got){skip++;continue} used+=got.buf.byteLength;
    let record;try{record=new TextDecoder().decode(gunzipSync(got.buf))}catch{skip++;continue}
    const parsed=parseWarc(record);if(!parsed){skip++;continue}
    const item=extract(parsed.html,parsed.target);if(!item){skip++;continue}
    item.content_hash=parsed.digest||'';
    const res=await fetch(endpoint,{method:'POST',headers:{'content-type':'application/json',authorization:`Bearer ${token}`},body:JSON.stringify({items:[item]})});
    if(res.ok){const d=await res.json();ok+=Number(d.imported||0)}else{console.error('import',res.status,await res.text())}
    await sleep(delayMs);
    if((ok+skip)%25===0)console.log({ok,skip,bytes:used});
  }
  console.log(JSON.stringify({crawl,pattern,records:records.length,imported:ok,skipped:skip,bytesRead:used,maxBytes},null,2));
}
main().catch(e=>{console.error(e.stack||e);process.exit(1)});
