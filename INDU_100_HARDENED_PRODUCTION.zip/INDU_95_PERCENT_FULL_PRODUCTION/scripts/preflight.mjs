#!/usr/bin/env node
import fs from 'node:fs';import path from 'node:path';import {execFileSync} from 'node:child_process';
const root=process.cwd();const required=['src/index.js','public/index.html','public/app.js','migrations/0007_100_percent.sql','migrations/0008_openweb_bootstrap.sql','scripts/commoncrawl-bootstrap.mjs','wrangler.jsonc'];
const missing=required.filter(x=>!fs.existsSync(path.join(root,x)));if(missing.length){console.error('Missing:',missing);process.exit(1)}
const checks=[['worker','src/index.js'],['app','public/app.js'],['kite','public/kite.js'],['sw','public/sw.js'],['cc','scripts/commoncrawl-bootstrap.mjs']];
for(const [name,file] of checks){execFileSync(process.execPath,['--check',file],{stdio:'inherit'});console.log(`OK ${name}`)}
const cfg=fs.readFileSync(path.join(root,'wrangler.jsonc'),'utf8');for(const bad of ['REPLACE_WITH_D1_DATABASE_ID','REPLACE_WITH_YOUR_WORKERS_SUBDOMAIN'])if(cfg.includes(bad))console.warn(`CONFIGURATION REQUIRED: ${bad}`);
console.log('Preflight complete. Configure D1, ALLOWED_ORIGIN, ADMIN_CRAWL_TOKEN, OPENROUTER_API_KEY, and optional search-provider keys before deployment.');
