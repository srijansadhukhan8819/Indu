# INDU changelog

## 1.3.0 — 90% milestone

- Added search operators: `site:`, `intitle:`, quoted phrases and `-excluded` terms.
- Added paginated search and candidate re-ranking with title, URL, description, freshness, importance and mode signals.
- Added short-lived hashed request rate limiting backed by D1.
- Added configurable blocked/threat domain filtering at the INDU search layer.
- Added sitemap discovery and queue prioritization.
- Added crawler support for `noindex` and `nofollow` signals and media discovery.
- Added indexed image/video media assets and `/api/media`.
- Added server-grounded INDU AI answers with source references.
- Added `/api/lens` for camera/clip actions using a configured vision-capable OpenRouter model.
- Added browser voice-search integration where supported.
- Added RSS/Atom news ingestion on the Worker cron.
- Added crawl retry/backoff and expanded observability schema.
- Improved offline shell caching for INDU assets and Kite branding.
- Expanded smoke tests from 3 to 5.

## 1.2.x — 80% milestone

See previous build history in the package README.

## 2.0.0 — INDU 100%
- Final application-layer production milestone.
- Added learned relevance signals from feedback.
- Added persisted URL graph scores and graph rebuild operation.
- Added freshness scheduling and recrawl classes.
- Added entity/knowledge-graph foundations.
- Added index version creation/activation and shard/region metadata.
- Added deterministic ranking experiments and SLO telemetry schema.
- Added global health and entity/status APIs.
- Added final production checklist and deployment notes.

## 2.1.0 — Hardened open-web bootstrap
- Added bounded Common Crawl URL-index + WARC byte-range ingestion.
- Added authenticated Common Crawl import endpoint.
- Added 100 MiB default bootstrap budget and configurable limits.
- Added open-web source bookkeeping migration.
- Added production preflight script and open-web deployment documentation.
