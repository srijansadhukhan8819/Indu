PRAGMA foreign_keys = ON;

-- Open-web bootstrap / Common Crawl ingestion bookkeeping.
CREATE TABLE IF NOT EXISTS commoncrawl_imports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  crawl_id TEXT NOT NULL,
  url TEXT NOT NULL,
  warc_filename TEXT,
  warc_offset INTEGER,
  warc_length INTEGER,
  content_digest TEXT,
  imported_at INTEGER NOT NULL,
  status TEXT NOT NULL,
  error TEXT
);
CREATE INDEX IF NOT EXISTS idx_cc_imports_crawl ON commoncrawl_imports(crawl_id, imported_at DESC);
CREATE INDEX IF NOT EXISTS idx_cc_imports_url ON commoncrawl_imports(url);

CREATE TABLE IF NOT EXISTS openweb_sources (
  source_id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  kind TEXT NOT NULL,
  base_url TEXT,
  enabled INTEGER NOT NULL DEFAULT 1,
  last_run_at INTEGER,
  last_status TEXT,
  documents_imported INTEGER NOT NULL DEFAULT 0,
  bytes_read INTEGER NOT NULL DEFAULT 0,
  updated_at INTEGER NOT NULL
);
