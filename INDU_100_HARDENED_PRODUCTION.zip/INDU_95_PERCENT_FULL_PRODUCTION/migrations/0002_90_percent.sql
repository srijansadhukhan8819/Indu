PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS rate_limits (
  key TEXT PRIMARY KEY,
  bucket INTEGER NOT NULL,
  hits INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_rate_limits_bucket ON rate_limits(bucket);

CREATE INDEX IF NOT EXISTS idx_documents_canonical ON documents(canonical_url);
CREATE INDEX IF NOT EXISTS idx_documents_lang ON documents(lang);
CREATE INDEX IF NOT EXISTS idx_documents_safe_fresh ON documents(safe,fetched_at DESC,importance DESC);
CREATE INDEX IF NOT EXISTS idx_queue_depth_priority ON crawl_queue(depth,priority DESC,discovered_at ASC);

CREATE TABLE IF NOT EXISTS crawl_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  url TEXT NOT NULL,
  status TEXT NOT NULL,
  http_status INTEGER,
  duration_ms INTEGER,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_crawl_events_created ON crawl_events(created_at DESC);

CREATE TABLE IF NOT EXISTS search_health (
  key TEXT PRIMARY KEY,
  value INTEGER NOT NULL DEFAULT 0,
  updated_at INTEGER NOT NULL
);


CREATE TABLE IF NOT EXISTS media_assets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  url TEXT NOT NULL UNIQUE,
  page_url TEXT NOT NULL,
  type TEXT NOT NULL,
  title TEXT NOT NULL DEFAULT '',
  alt TEXT NOT NULL DEFAULT '',
  domain TEXT NOT NULL DEFAULT '',
  discovered_at INTEGER NOT NULL,
  safe INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_media_type ON media_assets(type,discovered_at DESC);
CREATE INDEX IF NOT EXISTS idx_media_domain ON media_assets(domain);
