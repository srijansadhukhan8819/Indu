PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS documents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  url TEXT NOT NULL UNIQUE,
  canonical_url TEXT,
  title TEXT NOT NULL DEFAULT '',
  description TEXT NOT NULL DEFAULT '',
  text TEXT NOT NULL DEFAULT '',
  domain TEXT NOT NULL DEFAULT '',
  lang TEXT,
  fetched_at INTEGER NOT NULL,
  published_at INTEGER,
  status_code INTEGER,
  content_hash TEXT,
  word_count INTEGER NOT NULL DEFAULT 0,
  crawl_depth INTEGER NOT NULL DEFAULT 0,
  importance REAL NOT NULL DEFAULT 0,
  safe INTEGER NOT NULL DEFAULT 1,
  robots_allowed INTEGER NOT NULL DEFAULT 1
);

CREATE INDEX IF NOT EXISTS idx_documents_domain ON documents(domain);
CREATE INDEX IF NOT EXISTS idx_documents_fetched ON documents(fetched_at DESC);
CREATE INDEX IF NOT EXISTS idx_documents_importance ON documents(importance DESC);

CREATE VIRTUAL TABLE IF NOT EXISTS documents_fts USING fts5(
  title,
  description,
  text,
  content='documents',
  content_rowid='id',
  tokenize='unicode61 remove_diacritics 2'
);

CREATE TRIGGER IF NOT EXISTS documents_ai AFTER INSERT ON documents BEGIN
  INSERT INTO documents_fts(rowid,title,description,text)
  VALUES (new.id,new.title,new.description,new.text);
END;

CREATE TRIGGER IF NOT EXISTS documents_ad AFTER DELETE ON documents BEGIN
  INSERT INTO documents_fts(documents_fts,rowid,title,description,text)
  VALUES ('delete',old.id,old.title,old.description,old.text);
END;

CREATE TRIGGER IF NOT EXISTS documents_au AFTER UPDATE ON documents BEGIN
  INSERT INTO documents_fts(documents_fts,rowid,title,description,text)
  VALUES ('delete',old.id,old.title,old.description,old.text);
  INSERT INTO documents_fts(rowid,title,description,text)
  VALUES (new.id,new.title,new.description,new.text);
END;

CREATE TABLE IF NOT EXISTS crawl_queue (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  url TEXT NOT NULL UNIQUE,
  depth INTEGER NOT NULL DEFAULT 0,
  priority REAL NOT NULL DEFAULT 0,
  discovered_at INTEGER NOT NULL,
  last_attempt INTEGER,
  attempts INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'queued'
);

CREATE INDEX IF NOT EXISTS idx_queue_status_priority
ON crawl_queue(status, priority DESC, discovered_at ASC);

CREATE TABLE IF NOT EXISTS security_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT NOT NULL,
  query_hash TEXT,
  domain TEXT,
  created_at INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_security_events_created
ON security_events(created_at DESC);

CREATE TABLE IF NOT EXISTS news_cache (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  url TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  image_url TEXT,
  source TEXT,
  published_at INTEGER,
  topics TEXT,
  score REAL NOT NULL DEFAULT 0,
  fetched_at INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_news_score
ON news_cache(score DESC, published_at DESC);

CREATE TABLE IF NOT EXISTS crawl_hosts (
  host TEXT PRIMARY KEY,
  robots TEXT,
  fetched_at INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_documents_title ON documents(title);
CREATE INDEX IF NOT EXISTS idx_queue_attempts ON crawl_queue(status,attempts);
