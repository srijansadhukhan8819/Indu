PRAGMA foreign_keys = ON;

-- INDU 50% milestone: operational feedback, crawl governance and query-quality signals.
CREATE TABLE IF NOT EXISTS query_feedback (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  query_hash TEXT NOT NULL,
  url TEXT NOT NULL,
  action TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_query_feedback_created ON query_feedback(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_query_feedback_query ON query_feedback(query_hash,created_at DESC);

CREATE TABLE IF NOT EXISTS crawl_budgets (
  host TEXT PRIMARY KEY,
  requests INTEGER NOT NULL DEFAULT 0,
  window_started_at INTEGER NOT NULL,
  last_request_at INTEGER,
  min_delay_ms INTEGER NOT NULL DEFAULT 750,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_crawl_budgets_updated ON crawl_budgets(updated_at DESC);

CREATE TABLE IF NOT EXISTS index_snapshots (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  documents INTEGER NOT NULL DEFAULT 0,
  domains INTEGER NOT NULL DEFAULT 0,
  media INTEGER NOT NULL DEFAULT 0,
  queued INTEGER NOT NULL DEFAULT 0,
  failed INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_index_snapshots_created ON index_snapshots(created_at DESC);
