PRAGMA foreign_keys = ON;

-- INDU 95% milestone: large-search-engine-grade retrieval, operations, abuse and experimentation primitives.
CREATE TABLE IF NOT EXISTS abuse_reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  url TEXT NOT NULL,
  reason TEXT NOT NULL,
  details TEXT,
  created_at INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'open'
);
CREATE INDEX IF NOT EXISTS idx_abuse_reports_status ON abuse_reports(status,created_at DESC);

CREATE TABLE IF NOT EXISTS ranking_experiments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  variant TEXT NOT NULL,
  weight REAL NOT NULL DEFAULT 1,
  active INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  UNIQUE(name,variant)
);
CREATE INDEX IF NOT EXISTS idx_ranking_experiments_active ON ranking_experiments(active,name);

CREATE TABLE IF NOT EXISTS query_intents (
  query_hash TEXT PRIMARY KEY,
  intent TEXT NOT NULL,
  language TEXT NOT NULL,
  confidence REAL NOT NULL DEFAULT 0,
  seen_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_query_intents_seen ON query_intents(seen_at DESC);

CREATE TABLE IF NOT EXISTS search_sessions (
  session_hash TEXT PRIMARY KEY,
  query_count INTEGER NOT NULL DEFAULT 0,
  click_count INTEGER NOT NULL DEFAULT 0,
  last_query_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_search_sessions_last ON search_sessions(last_query_at DESC);

CREATE TABLE IF NOT EXISTS index_versions (
  version_id TEXT PRIMARY KEY,
  status TEXT NOT NULL,
  documents INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  activated_at INTEGER,
  notes TEXT
);
CREATE INDEX IF NOT EXISTS idx_index_versions_status ON index_versions(status,created_at DESC);

CREATE TABLE IF NOT EXISTS canonical_clusters (
  content_hash TEXT PRIMARY KEY,
  canonical_url TEXT NOT NULL,
  duplicate_count INTEGER NOT NULL DEFAULT 1,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_canonical_clusters_updated ON canonical_clusters(updated_at DESC);

CREATE TABLE IF NOT EXISTS crawl_leases (
  host TEXT PRIMARY KEY,
  lease_until INTEGER NOT NULL,
  worker_id TEXT NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_crawl_leases_until ON crawl_leases(lease_until);

CREATE TABLE IF NOT EXISTS api_audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  route TEXT NOT NULL,
  status INTEGER NOT NULL,
  latency_ms INTEGER NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_api_audit_created ON api_audit_log(created_at DESC);
