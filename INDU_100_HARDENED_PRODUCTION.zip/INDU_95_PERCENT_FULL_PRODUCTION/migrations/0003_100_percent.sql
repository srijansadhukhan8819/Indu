PRAGMA foreign_keys = ON;

CREATE INDEX IF NOT EXISTS idx_documents_safe_domain_importance ON documents(safe,domain,importance DESC);
CREATE INDEX IF NOT EXISTS idx_documents_published ON documents(published_at DESC);
CREATE INDEX IF NOT EXISTS idx_media_search ON media_assets(type,safe,domain,discovered_at DESC);

CREATE TABLE IF NOT EXISTS search_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  query_hash TEXT NOT NULL,
  mode TEXT NOT NULL DEFAULT 'auto',
  provider TEXT NOT NULL DEFAULT 'local',
  result_count INTEGER NOT NULL DEFAULT 0,
  latency_ms INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_search_events_created ON search_events(created_at DESC);

CREATE TABLE IF NOT EXISTS crawl_frontier (
  url TEXT PRIMARY KEY,
  host TEXT NOT NULL,
  depth INTEGER NOT NULL DEFAULT 0,
  priority REAL NOT NULL DEFAULT 0,
  discovered_at INTEGER NOT NULL,
  last_crawled_at INTEGER,
  next_crawl_at INTEGER,
  status TEXT NOT NULL DEFAULT 'queued'
);
CREATE INDEX IF NOT EXISTS idx_frontier_schedule ON crawl_frontier(status,next_crawl_at,priority DESC);

CREATE TABLE IF NOT EXISTS domain_policies (
  domain TEXT PRIMARY KEY,
  crawl_allowed INTEGER NOT NULL DEFAULT 1,
  search_allowed INTEGER NOT NULL DEFAULT 1,
  safe INTEGER NOT NULL DEFAULT 1,
  updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS query_suggestions (
  query TEXT PRIMARY KEY,
  popularity INTEGER NOT NULL DEFAULT 0,
  updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS index_jobs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'queued',
  payload TEXT,
  created_at INTEGER NOT NULL,
  started_at INTEGER,
  finished_at INTEGER,
  error TEXT
);
CREATE INDEX IF NOT EXISTS idx_index_jobs_status ON index_jobs(status,created_at);
