PRAGMA foreign_keys = ON;

-- INDU 100% milestone: complete product/operations layer.
-- This is the final application-layer schema for the INDU specification.

CREATE TABLE IF NOT EXISTS learned_rank_signals (
  query_hash TEXT NOT NULL,
  url TEXT NOT NULL,
  signal INTEGER NOT NULL DEFAULT 0,
  weight REAL NOT NULL DEFAULT 0,
  updated_at INTEGER NOT NULL,
  PRIMARY KEY(query_hash,url)
);
CREATE INDEX IF NOT EXISTS idx_learned_rank_url ON learned_rank_signals(url,updated_at DESC);

CREATE TABLE IF NOT EXISTS url_rank_scores (
  url TEXT PRIMARY KEY,
  score REAL NOT NULL DEFAULT 0,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_url_rank_score ON url_rank_scores(score DESC);

CREATE TABLE IF NOT EXISTS freshness_schedule (
  document_id INTEGER PRIMARY KEY,
  next_crawl_at INTEGER NOT NULL,
  class TEXT NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_freshness_due ON freshness_schedule(next_crawl_at,class);

CREATE TABLE IF NOT EXISTS entity_catalog (
  entity_id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  kind TEXT NOT NULL,
  description TEXT,
  canonical_url TEXT,
  language TEXT,
  popularity REAL NOT NULL DEFAULT 0,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_entity_name ON entity_catalog(name);

CREATE TABLE IF NOT EXISTS entity_aliases (
  alias TEXT PRIMARY KEY,
  entity_id TEXT NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_entity_alias_entity ON entity_aliases(entity_id);

CREATE TABLE IF NOT EXISTS region_health (
  region TEXT PRIMARY KEY,
  endpoint TEXT,
  status TEXT NOT NULL DEFAULT 'unknown',
  latency_ms INTEGER,
  checked_at INTEGER NOT NULL,
  error_rate REAL NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_region_health_status ON region_health(status,checked_at DESC);

CREATE TABLE IF NOT EXISTS experiment_assignments (
  experiment TEXT NOT NULL,
  subject_hash TEXT NOT NULL,
  variant TEXT NOT NULL,
  assigned_at INTEGER NOT NULL,
  PRIMARY KEY(experiment,subject_hash)
);
CREATE INDEX IF NOT EXISTS idx_experiment_variant ON experiment_assignments(experiment,variant);

CREATE TABLE IF NOT EXISTS slo_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  route TEXT NOT NULL,
  latency_ms INTEGER NOT NULL,
  status INTEGER NOT NULL,
  region TEXT,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_slo_route_time ON slo_events(route,created_at DESC);

CREATE TABLE IF NOT EXISTS crawl_host_state (
  host TEXT PRIMARY KEY,
  next_allowed_at INTEGER NOT NULL DEFAULT 0,
  in_flight INTEGER NOT NULL DEFAULT 0,
  last_status INTEGER,
  last_error TEXT,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_crawl_host_due ON crawl_host_state(next_allowed_at);

CREATE TABLE IF NOT EXISTS index_shards (
  shard_id TEXT PRIMARY KEY,
  region TEXT NOT NULL,
  status TEXT NOT NULL,
  document_count INTEGER NOT NULL DEFAULT 0,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_index_shards_region ON index_shards(region,status);

CREATE TABLE IF NOT EXISTS knowledge_facts (
  subject_id TEXT NOT NULL,
  predicate TEXT NOT NULL,
  object_text TEXT NOT NULL,
  source_url TEXT,
  confidence REAL NOT NULL DEFAULT 0,
  updated_at INTEGER NOT NULL,
  PRIMARY KEY(subject_id,predicate,object_text)
);
CREATE INDEX IF NOT EXISTS idx_knowledge_subject ON knowledge_facts(subject_id);

CREATE TABLE IF NOT EXISTS search_quality_daily (
  day TEXT PRIMARY KEY,
  searches INTEGER NOT NULL DEFAULT 0,
  clicks INTEGER NOT NULL DEFAULT 0,
  helpful INTEGER NOT NULL DEFAULT 0,
  not_helpful INTEGER NOT NULL DEFAULT 0,
  zero_result INTEGER NOT NULL DEFAULT 0,
  avg_latency_ms REAL NOT NULL DEFAULT 0,
  updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS deployment_releases (
  release_id TEXT PRIMARY KEY,
  version TEXT NOT NULL,
  status TEXT NOT NULL,
  checksum TEXT,
  created_at INTEGER NOT NULL,
  activated_at INTEGER,
  notes TEXT
);
CREATE INDEX IF NOT EXISTS idx_release_status ON deployment_releases(status,created_at DESC);
