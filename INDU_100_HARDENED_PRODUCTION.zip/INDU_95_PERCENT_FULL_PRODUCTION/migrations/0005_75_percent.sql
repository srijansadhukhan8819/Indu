PRAGMA foreign_keys = ON;

-- INDU 75% milestone: scalable retrieval, quality, deduplication and operational intelligence.
CREATE TABLE IF NOT EXISTS document_links (
  source_url TEXT NOT NULL,
  target_url TEXT NOT NULL,
  anchor_text TEXT,
  created_at INTEGER NOT NULL,
  PRIMARY KEY(source_url,target_url)
);
CREATE INDEX IF NOT EXISTS idx_document_links_target ON document_links(target_url);
CREATE INDEX IF NOT EXISTS idx_document_links_source ON document_links(source_url);

CREATE TABLE IF NOT EXISTS query_quality (
  query_hash TEXT PRIMARY KEY,
  impressions INTEGER NOT NULL DEFAULT 0,
  clicks INTEGER NOT NULL DEFAULT 0,
  helpful INTEGER NOT NULL DEFAULT 0,
  reformulations INTEGER NOT NULL DEFAULT 0,
  last_seen INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS host_health (
  host TEXT PRIMARY KEY,
  success_count INTEGER NOT NULL DEFAULT 0,
  error_count INTEGER NOT NULL DEFAULT 0,
  avg_latency_ms REAL NOT NULL DEFAULT 0,
  last_status INTEGER,
  last_seen INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_host_health_seen ON host_health(last_seen DESC);

CREATE TABLE IF NOT EXISTS search_cache (
  cache_key TEXT PRIMARY KEY,
  payload TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_search_cache_expiry ON search_cache(expires_at);

CREATE TABLE IF NOT EXISTS crawl_domains (
  domain TEXT PRIMARY KEY,
  state TEXT NOT NULL DEFAULT 'active',
  priority REAL NOT NULL DEFAULT 1,
  max_depth INTEGER NOT NULL DEFAULT 4,
  max_pages INTEGER NOT NULL DEFAULT 10000,
  pages_crawled INTEGER NOT NULL DEFAULT 0,
  last_crawled INTEGER,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_crawl_domains_priority ON crawl_domains(priority DESC,state);

CREATE TABLE IF NOT EXISTS ranking_signals (
  document_id INTEGER PRIMARY KEY,
  link_score REAL NOT NULL DEFAULT 0,
  quality_score REAL NOT NULL DEFAULT 0,
  freshness_score REAL NOT NULL DEFAULT 0,
  updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS index_jobs_75 (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  job_type TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'queued',
  cursor TEXT,
  processed INTEGER NOT NULL DEFAULT 0,
  errors INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
